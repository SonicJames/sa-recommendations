/* SonicApply redesign prototype: interaction layer (v2) */
(() => {
  const D = window.SA_DATA;
  const C = D.candidate;
  const W = D.why;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const wait = ms => new Promise(r => setTimeout(r, reduce ? 0 : ms));
  const plural = (n, one, many) => n === 1 ? one : (many || one + "s");

  const I = {
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>',
    send: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>',
    doc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
    upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>',
    sparkle: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l1.8 5.2L19 9l-5.2 1.8L12 16l-1.8-5.2L5 9l5.2-1.8z"/><path d="M19 14l.9 2.6 2.6.9-2.6.9L19 21l-.9-2.6-2.6-.9 2.6-.9z"/></svg>',
    mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><polyline points="3 7 12 13 21 7"/></svg>',
    eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  };
  const OTP_EMOJI = ["\u{1F60A}", "\u{1F604}", "\u{1F973}", "\u{1F60E}", "\u{1F929}", "✨"];
  const STAGES = [
    { e: "\u{1F4C4}", t: "Analyzing your resume…" },
    { e: "✨", t: "Extracting your experience…" },
    { e: "\u{1F4BC}", t: "Identifying key skills…" },
    { e: "\u{1F3AF}", t: "Preparing your application…" },
  ];

  const state = {
    step: 1, opened: false,
    identity: null, lookup: null, unlocked: false, resumeConfirmed: false, processing: false, otpMode: "send", resumeRow: null,
    resume: null, formActive: false, filled: false,
    a: { backup: null, locpref: null, relocate: null },
    pref: { area: "sa", practice: "any" },
    selected: new Set(), step2Ready: false,
    answers: {}, verified: false, sent: [], step3Seen: false,
    email: null, notifyEmail: null, goalDone: false, more: null,
    pending: {}, startRow: null, areaRow: null, practiceRow: null, prefsBound: false,
    busy: 0, noPhone: false,
  };

  /* ================= Thread (CareerGPT rail) ================= */
  const thread = $("#thread");
  let chain = Promise.resolve();

  /* Mobile strip: mirrors the latest agent row (thinking state, text, chips) above the form. Chip taps are forwarded to the
     real chips in the thread, so there is one source of truth. The sheet shows the whole thread on request. */
  const strip = { text: $("#strip-text"), chips: $("#strip-chips"), row: null };
  function syncStrip() {
    const row = strip.row; if (!row) return;
    const think = row.querySelector(".think");
    if (think) strip.text.innerHTML = think.outerHTML;
    else { const t = row.querySelector(".msg-text"); strip.text.textContent = t ? t.textContent : ""; }
    /* Chips: the latest row's, or, if it has none, the most recent question still waiting for an answer. */
    let src = row.querySelector(".chips, .msg-links");
    if (!src && !think) { const open = $$(".msg .chips:not(.answered)", thread).filter(c => !c.closest(".past")); src = open[open.length - 1] || null; }
    strip.chips.innerHTML = "";
    if (src && !think) {
      $$("button", src).forEach(orig => {
        const b = document.createElement("button");
        b.type = "button"; b.className = "chip" + (orig.classList.contains("on") ? " on" : "");
        b.innerHTML = orig.innerHTML;
        b.onclick = () => { orig.click(); syncStrip(); };
        strip.chips.appendChild(b);
      });
      if (src.classList.contains("answered")) strip.chips.classList.add("answered"); else strip.chips.classList.remove("answered");
    }
    strip.chips.hidden = !strip.chips.children.length;
  }
  function openSheet() { $("#rail").classList.add("open"); $("#sheet-backdrop").classList.add("show"); scrollThread(); }
  function closeSheet() { $("#rail").classList.remove("open"); $("#sheet-backdrop").classList.remove("show"); }
  $("#strip-open").addEventListener("click", openSheet);
  $("#strip-chat").addEventListener("click", openSheet);
  $("#rail-close").addEventListener("click", closeSheet);
  $("#sheet-backdrop").addEventListener("click", closeSheet);
  const scrollThread = () => thread.scrollTo({ top: thread.scrollHeight, behavior: reduce ? "auto" : "smooth" });
  const stamp = () => { const d = new Date(); return d.toLocaleDateString("en-US", { weekday: "long" }) + " " + d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false }); };
  function setBusy(delta) { state.busy = Math.max(0, state.busy + delta); document.body.classList.toggle("is-busy", state.busy > 0); }

  async function streamText(el, text) {
    if (reduce) { el.textContent = text; return; }
    const tokens = text.match(/\S+\s*/g) || [text];
    const per = Math.min(40, Math.max(14, 900 / tokens.length));
    const start = performance.now();
    let shown = 0;
    el.innerHTML = '<span class="tt"></span><span class="caret"></span>';
    const tt = el.querySelector(".tt");
    while (shown < tokens.length) {
      await wait(per);
      shown = Math.min(tokens.length, Math.max(shown + 1, Math.floor((performance.now() - start) / per)));
      tt.textContent = tokens.slice(0, shown).join("");
      if (shown % 3 === 0) { scrollThread(); syncStrip(); }
    }
    el.textContent = text;
  }

  function thinkingRow(label) {
    const t = document.createElement("div");
    t.className = "think";
    t.innerHTML = `<span class="tdot"></span><span class="tlabel">${esc(label || "Thinking…")}</span>`;
    return t;
  }

  /* agent(): serialized assistant turn. Shows the thinking state for `think` ms or until `until` settles, then an optional
     meta line ("Read your resume in 6s"), then streams the text, then attaches a card, chips or links. */
  function agent(text, opts = {}) {
    const p = chain.then(async () => {
      setBusy(1);
      const row = document.createElement("div");
      row.className = "msg";
      const t = thinkingRow(opts.thinkLabel);
      row.appendChild(t);
      thread.appendChild(row);
      strip.row = row; syncStrip();
      scrollThread();
      if (opts.until) await opts.until; else await wait(opts.think ?? 650);
      t.remove();
      if (opts.meta) { const m = document.createElement("div"); m.className = "meta"; m.textContent = opts.meta; row.appendChild(m); }
      const body = document.createElement("div"); body.className = "msg-text"; row.appendChild(body);
      await streamText(body, text);
      if (opts.card) row.appendChild(opts.card);
      if (opts.chips) row.appendChild(opts.chips);
      if (opts.links) {
        const l = document.createElement("div"); l.className = "msg-links";
        opts.links.forEach(k => { const b = document.createElement("button"); b.type = "button"; b.textContent = k.label; b.onclick = k.onClick; l.appendChild(b); });
        row.appendChild(l);
      }
      syncStrip();
      scrollThread();
      await wait(opts.after ?? 120);
      setBusy(-1);
      return row;
    });
    chain = p.catch(() => setBusy(-1));
    return p;
  }

  /* collapseThread(): folds everything said so far into one row ("Apply · sent"), so each step starts with a clean rail.
     Serialized on the chain so an in-flight reply finishes first. */
  function collapseThread(label) {
    const p = chain.then(() => {
      const nodes = Array.from(thread.children).filter(n => !n.classList.contains("past"));
      if (!nodes.length) return;
      const d = document.createElement("details");
      d.className = "past";
      d.innerHTML = `<summary><span class="pill">${I.check}${esc(label)}</span><span class="show"></span></summary><div class="past-body"></div>`;
      const body = d.querySelector(".past-body");
      nodes.forEach(n => body.appendChild(n));
      thread.appendChild(d);
      scrollThread();
    });
    chain = p.catch(() => {});
    return p;
  }

  function user(text, opts = {}) {
    const wrap = document.createElement("div");
    wrap.className = "user-wrap";
    wrap.innerHTML = `<div class="user${opts.attachment ? " att" : ""}">${opts.attachment ? I.doc : ""}<span>${esc(text)}</span></div><div class="user-meta">${esc(stamp())}</div>`;
    thread.appendChild(wrap);
    scrollThread();
  }

  function chipRow(options, onPick) {
    const wrap = document.createElement("div");
    wrap.className = "chips";
    options.forEach(o => {
      const b = document.createElement("button");
      b.type = "button"; b.className = "chip"; b.dataset.value = o.value;
      b.innerHTML = `<span>${esc(o.label)}</span>${o.count != null ? `<span class="n">${o.count}</span>` : ""}`;
      b.onclick = () => { markChip(wrap, b); onPick(o); };
      wrap.appendChild(b);
    });
    return wrap;
  }
  function markChip(wrap, b) { $$(".chip", wrap).forEach(c => c.classList.remove("on")); b.classList.add("on"); wrap.classList.add("answered"); syncStrip(); }
  function refreshCounts(wrap, options) { if (!wrap) return; options.forEach(o => { const n = wrap.querySelector(`.chip[data-value="${o.value}"] .n`); if (n) n.textContent = o.count; }); syncStrip(); }

  /* ask(): question + chips. Resolves on the first pick; later picks still call onPick. state.pending[id].answer() lets the
     form (or the right-hand controls) answer the same question without a user bubble. */
  function ask(id, text, options, { onPick, think, thinkLabel, meta } = {}) {
    return new Promise(resolve => {
      let first = true;
      const row = chipRow(options, o => { user(o.label); onPick && onPick(o, first); if (first) { first = false; resolve(o); } });
      state.pending[id] = {
        row,
        answer: value => { const b = row.querySelector(`.chip[data-value="${value}"]`); if (b) markChip(row, b); if (first) { first = false; resolve(options.find(o => o.value === value) || { value }); } },
      };
      agent(text, { chips: row, think, thinkLabel, meta });
    });
  }

  /* ================= Workspace helpers ================= */
  const workScroll = $("#work-scroll");
  const work = $("#work-inner");
  const cta = $("#cta");
  function setWork(html) { work.innerHTML = html; work.classList.remove("swap"); void work.offsetWidth; work.classList.add("swap"); workScroll.scrollTop = 0; }
  function setCta(html) { cta.innerHTML = html; cta.style.display = html ? "" : "none"; syncRevBar(); }
  /* On a phone the chat is the page and the form is a sheet you open to review and correct. On desktop these are no-ops. */
  const STEP_TITLES = { 1: "Your application", 2: "Matching jobs", 3: "Confirm and send" };
  function openReview() { document.body.classList.add("review-open"); workScroll.scrollTop = 0; }
  function closeReview() { document.body.classList.remove("review-open"); scrollThread(); }
  function syncRevBar() {
    const t = $("#rb-t"); if (!t) return;
    const meta = cta.querySelector(".cta-meta span:last-child, .cta-meta > span");
    t.textContent = STEP_TITLES[state.step] || "Your application";
    $("#rb-s").textContent = meta ? meta.textContent.replace(/\s+/g, " ").trim() : "Start with your email";
    $("#work-title").textContent = STEP_TITLES[state.step] || "";
  }
  $("#revbar").addEventListener("click", openReview);
  $("#work-back").addEventListener("click", closeReview);
  function setStep(n) {
    state.step = n;
    $$(".step").forEach((s, i) => { s.classList.toggle("is-done", i + 1 < n); s.classList.toggle("is-current", i + 1 === n); });
    $$(".step-line").forEach((l, i) => l.classList.toggle("is-done", i + 1 < n));
    $$(".note-step").forEach(ns => ns.classList.toggle("is-current", ns.dataset.step === String(n)));
    document.body.classList.remove("review-open"); syncRevBar();
  }
  function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove("show"), 2200); }
  const mono = name => name.split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase();
  function bindToasts() { $$("[data-toast]").forEach(elm => { if (elm.dataset.bound) return; elm.dataset.bound = "1"; elm.addEventListener("click", e => { e.preventDefault(); toast(elm.dataset.toast); }); }); }


  /* ================= Asking in the chat =================
     Principle: the chat asks, the form reviews. Every answer the resume couldn't supply is asked in the chat (one place, so it
     works the same on a phone where the two can't sit side by side). The form shows those fields as "in the chat" until they
     are answered, then it is where you check and correct. Open text is validated the same way everywhere: a quiet reason on
     the field, and in the chat the exact problem, an echo of what was typed with the problem marked, and a retry in the composer. */
  const textAsk = { key: null, handle: null, tries: 0, resolve: null };
  const isMobile = () => window.matchMedia("(max-width: 920px)").matches;
  function setAwaiting(on, ph, mode) {
    const f = $("#composer"), inp = $("#composer input");
    f.classList.toggle("awaiting", !!on);
    inp.placeholder = on ? (ph || "Type your answer…") : "Ask a follow-up…";
    inp.setAttribute("inputmode", on ? (mode || "text") : "text");
    if (on && !isMobile()) setTimeout(() => inp.focus(), 50);
  }
  function endTextAsk() {
    const r = textAsk.resolve;
    Object.assign(textAsk, { key: null, handle: null, tries: 0, resolve: null, qid: null });
    setAwaiting(false);
    if (r) r();
  }
  /* Open an ask: the next thing typed in the composer goes to `handle`. Resolves when endTextAsk() is called. */
  function openTextAsk(handle, ph, mode, extra = {}) {
    return new Promise(resolve => { Object.assign(textAsk, { handle, tries: 0, resolve, key: null, qid: null }, extra); setAwaiting(true, ph, mode); });
  }
  function inChat(w, on) {
    if (!w) return;
    const hint = w.querySelector(".hint");
    if (hint && !hint.dataset.orig) hint.dataset.orig = hint.textContent;
    w.classList.toggle("in-chat", !!on);
    if (on) w.classList.remove("needs", "done");
    if (hint && !w.classList.contains("invalid")) { hint.className = "hint"; hint.textContent = on ? "CareerGPT is asking this one in the chat." : hint.dataset.orig; }
    const inp = w.querySelector("input"); if (inp) inp.readOnly = !!on;
    const s = w.querySelector("select"); if (s) s.disabled = !!on;
  }

  const PHONE_EX = "(555) 123-4567";
  function validatePhone(raw) {
    const s = String(raw || "").trim();
    if (!s) return { ok: false, code: "empty" };
    const digits = s.replace(/\D/g, "");
    if (/[A-Za-z]/.test(s.replace(/\b(ext|x)\.?\s*\d+$/i, ""))) return { ok: false, code: "letters", raw: s, digits };
    if (/^\s*\+/.test(s) && !/^\s*\+\s*1\b/.test(s)) return { ok: false, code: "nonus", raw: s, digits };
    let d = digits;
    if (d.length === 11 && d[0] === "1") d = d.slice(1);
    if (d.length < 10) return { ok: false, code: "short", raw: s, digits: d };
    if (d.length > 10) return { ok: false, code: "long", raw: s, digits: d };
    if (/^[01]/.test(d)) return { ok: false, code: "area", raw: s, digits: d };
    if (/^(\d)\1{9}$/.test(d)) return { ok: false, code: "fake", raw: s, digits: d };
    return { ok: true, value: `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`, digits: d };
  }
  const TYPO = { "gmial.com": "gmail.com", "gmai.com": "gmail.com", "gnail.com": "gmail.com", "gmail.co": "gmail.com", "yahho.com": "yahoo.com", "yaho.com": "yahoo.com", "hotmial.com": "hotmail.com", "outlok.com": "outlook.com", "iclod.com": "icloud.com" };
  function validateEmail(raw, main) {
    const s = String(raw || "").trim();
    if (!s) return { ok: false, code: "empty" };
    if (/\s/.test(s)) return { ok: false, code: "space", raw: s };
    if (!s.includes("@")) return { ok: false, code: "noat", raw: s };
    if (!EMAIL_RE.test(s)) return { ok: false, code: "format", raw: s };
    const at = s.lastIndexOf("@"), fix = TYPO[s.slice(at + 1).toLowerCase()];
    if (fix) return { ok: false, code: "typo", raw: s, suggest: s.slice(0, at + 1) + fix };
    if (main && s.toLowerCase() === String(main).toLowerCase()) return { ok: false, code: "same", raw: s };
    return { ok: true, value: s };
  }

  /* Per-field copy: `inline` is the one-line reason on the form field, `chat` is what CareerGPT says. */
  const FIELDS = {
    phone: {
      id: "f-phone", ph: "Type your phone number…", mode: "tel", ex: PHONE_EX, validate: raw => validatePhone(raw),
      inline: { letters: "Numbers only, please.", nonus: "West Alamo only takes US numbers.", short: v => `That's ${v.digits.length} digits. US numbers have 10.`, long: v => `That's ${v.digits.length} digits. US numbers have 10.`, area: "US area codes don't start with 0 or 1.", fake: "That looks like a placeholder." },
      chat: {
        short: v => `That number has ${v.digits.length} digits and a US phone number has 10, so it looks like one is missing. Check it against your phone and send it again. Any format works.`,
        long: v => `That number has ${v.digits.length} digits, one or more too many for a US number. Send it again with just the 10 digits. Any format works.`,
        letters: () => "I found letters in that. West Alamo's form only takes digits, so I can't submit it as typed. What's the number?",
        nonus: () => "That looks like a number from outside the US. West Alamo's form only accepts US phone numbers. Do you have a US number they can reach you on?",
        area: () => "US area codes never start with 0 or 1, so that one won't go through. Could you check the first three digits?",
        fake: () => "That looks like a placeholder rather than a real number. What number should West Alamo call?",
      },
      ok: v => `Got it, ${v.value}. West Alamo will use it for interview calls and nothing else.`,
    },
    backup: {
      id: "f-backup", ph: "Type a second email…", mode: "email", ex: "name@example.com", validate: raw => validateEmail(raw, state.email || ($("#f-email") || {}).value),
      inline: { space: "Remove the spaces.", noat: "An email needs an @.", format: "That doesn't look like a full email address.", typo: v => `Did you mean ${v.suggest.split("@")[1]}?`, same: "That's your main email. Use a different one." },
      chat: {
        space: () => "There's a space in that address. Send it again without spaces?",
        noat: () => "That's missing an @, so it isn't an email address yet. What's the full address?",
        format: () => "That doesn't look like a full email address. It should be like name@example.com. What should I use?",
        typo: v => `Is that ${v.suggest}? The part after the @ looks like a typo.`,
        same: () => "That's the same as your main email. West Alamo rejects an application if the first email is already registered, so the backup has to be a different address.",
      },
      ok: v => `Got it, ${v.value} is your backup.`,
    },
  };

  function vcard(v, F) {
    const d = v.digits || "";
    let val = esc(v.raw || "");
    if (v.code === "letters") val = esc(v.raw).replace(/[A-Za-z]+/g, m => `<mark>${m}</mark>`);
    if (v.code === "nonus") val = esc(v.raw).replace(/^\s*\+\s*\d+/, m => `<mark>${m}</mark>`);
    if (v.code === "noat") val = `${esc(v.raw)}<mark>&nbsp;</mark>`;
    if (v.code === "space") val = esc(v.raw).replace(/\s+/g, m => `<mark>${m.replace(/ /g, "&nbsp;")}</mark>`);
    if (v.code === "typo") { const at = v.raw.lastIndexOf("@"); val = `${esc(v.raw.slice(0, at + 1))}<mark>${esc(v.raw.slice(at + 1))}</mark>`; }
    let meter = "";
    if (v.code === "short" || v.code === "long") {
      const slots = Array.from({ length: Math.max(10, d.length) }, (_, i) => `<i class="${i < Math.min(d.length, 10) ? "on" : ""}${i >= 10 ? "over" : ""}"></i>`).join("");
      meter = `<div class="v-meter"><span class="v-slots" aria-hidden="true">${slots}</span><span>${d.length} of 10 digits</span></div>`;
    }
    const ex = ["nonus", "letters", "area", "fake", "format", "noat"].includes(v.code) ? `<div class="v-ex">Like this: <b>${esc(F.ex)}</b></div>` : "";
    const c = document.createElement("div"); c.className = "vcard";
    c.innerHTML = `<div class="v-k">You entered</div><div class="v-val">${val}</div>${meter}${ex}`;
    return c;
  }

  /* One entry point for every way a value for these fields arrives. source: "chat" (composer), "form" (typed on the form,
     which only ever shows the quiet inline reason), "submit" (Submit pressed with a bad value). */
  function fieldFeedback(key, raw, source) {
    const F = FIELDS[key], w = $(`#${F.id}-w`), inp = $("#" + F.id), hint = w.querySelector(".hint");
    if (!hint.dataset.orig) hint.dataset.orig = hint.textContent;
    const clear = () => { w.classList.remove("invalid"); inp.removeAttribute("aria-invalid"); hint.className = "hint"; hint.textContent = hint.dataset.orig; };
    const v = F.validate(raw);
    const asking = textAsk.key === key;
    if (v.ok) {
      clear(); inp.value = v.value; inChat(w, false); w.classList.remove("needs"); w.classList.add("done");
      if (key === "backup") { state.a.backup = v.value; if (state.pending.backup) state.pending.backup.answer(v.value); }
      updateProgress();
      if (asking) { agent(F.ok(v), { think: 250 }); endTextAsk(); }
      return v;
    }
    if (v.code === "empty") { clear(); return v; }
    w.classList.remove("needs", "done", "in-chat"); inp.readOnly = false; w.classList.add("invalid"); inp.setAttribute("aria-invalid", "true");
    const t = F.inline[v.code]; const line = typeof t === "function" ? t(v) : t;
    hint.className = "hint err";
    hint.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><span>${esc(line)} Example: ${esc(F.ex)}</span>`;
    updateProgress();
    if (source === "form" && !asking) return v;          /* correcting on the form: the reason on the field is enough */
    if (!asking) { Object.assign(textAsk, { key, handle: t => fieldFeedback(key, t, "chat"), tries: 0 }); setAwaiting(true, F.ph, F.mode); }
    textAsk.tries += 1;
    const text = textAsk.tries >= 3 ? `Still not a match. Here's the shape West Alamo wants: ${F.ex}. You can also fix it on the form.` : F.chat[v.code](v);
    let chips = null;
    if (v.code === "typo") chips = chipRow([{ value: "yes", label: `Use ${v.suggest}` }, { value: "no", label: "No, keep mine" }], o => { if (o.value === "yes") fieldFeedback(key, v.suggest, "chat"); else { inp.value = v.raw; agent("Okay, I'll leave it as you typed it.", { think: 200 }); w.classList.remove("invalid"); clear(); inChat(w, false); w.classList.add("done"); if (key === "backup") state.a.backup = v.raw; updateProgress(); endTextAsk(); } });
    if (v.code === "nonus") chips = chipRow([{ value: "yes", label: "Yes, I'll type it" }, { value: "no", label: "I don't have one" }], o => {
      if (o.value === "yes") agent("Go ahead and type it below.", { think: 200 });
      else agent("Then I can't submit this application yet, because West Alamo requires a US number. Add one whenever you have it and I'll pick up from here. Your answers are saved.", { think: 400 });
    });
    agent(text, { card: vcard(v, F), chips, think: 450, thinkLabel: "Checking it…" });
    return v;
  }
  /* Ask for a field in the chat; resolves when a valid value is in. */
  function askField(key, prompt, opts = {}) {
    const F = FIELDS[key], w = $(`#${F.id}-w`);
    inChat(w, true);
    const done = openTextAsk(t => fieldFeedback(key, t, "chat"), F.ph, F.mode, { key });
    agent(prompt, { think: opts.think ?? 450, chips: opts.chips });
    return done;
  }

  /* The start email and the 6-digit code can be typed in the chat too, so a phone never needs the form to begin. */
  function startEmailFromChat(t) {
    const v = validateEmail(t);
    if (!v.ok) {
      const F = { ex: "name@example.com" };
      const typo = v.code === "typo";
      const msg = { space: "There's a space in that address. Send it again without spaces?", noat: "That's missing an @, so it isn't an email address yet. What's the full address?", format: "That doesn't look like a full email address. It should be like name@example.com. What should I use?", typo: `Is that ${v.suggest}? The part after the @ looks like a typo.` }[v.code] || "What's your email address?";
      const chips = typo ? chipRow([{ value: "yes", label: `Use ${v.suggest}` }, { value: "no", label: "No, keep mine" }], o => startEmailFromChat(o.value === "yes" ? v.suggest : v.raw)) : null;
      agent(msg, { card: vcard(v, F), chips, think: 450, thinkLabel: "Checking it…" });
      return;
    }
    endTextAsk();
    $("#f-start").value = v.value;
    state.lookup = isKnownEmail(v.value) ? "returning" : "new";
    startWithEmail(true);
  }
  function codeFromChat(t) {
    const d = t.replace(/\D/g, "");
    const boxes = $$("#otp input");
    if (d.length !== 6 || !boxes.length) {
      agent(`Codes are 6 digits${d.length ? ` and that was ${d.length}` : ""}. Check the text we sent to ${state.maskedPhone || "your phone"} and try again.`, { think: 350 });
      return;
    }
    boxes.forEach((b, i) => { b.value = d[i]; });
    boxes[5].dispatchEvent(new Event("input", { bubbles: true }));
  }
  function askCode() { Object.assign(textAsk, { key: "otp", handle: codeFromChat, tries: 0 }); setAwaiting(true, "Type the 6-digit code…", "numeric"); }

  /* ================= STEP 1: the first application ================= */
  /* Two paths from one email field. Known email: verify by text now, then the saved resume and answers load (nothing to
     verify later). Unknown email: resume first, verify before the batch send. */
  const LOC = [{ value: "San Antonio", label: "San Antonio" }, { value: "Austin", label: "Austin" }, { value: "Dallas", label: "Dallas" }, { value: "Houston", label: "Houston" }];
  const EEO = ["Prefer not to say"];
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isKnownEmail = e => e.trim().toLowerCase() === D.saved.email.toLowerCase();
  const sel = (id, opts, value, why, placeholder) => `<div class="f" id="${id}-w"><label for="${id}">${placeholder}${why ? ` <span class="need">Needs you</span><span class="ok">${I.check}</span>` : ""}</label><select id="${id}">${value === "" ? `<option value="">Choose</option>` : ""}${opts.map(o => `<option${o === value ? " selected" : ""}>${esc(o)}</option>`).join("")}</select>${why ? `<div class="hint">${esc(why)}</div>` : ""}</div>`;
  const field = (id, label, why, ph = "") => `<div class="f" id="${id}-w"><label for="${id}">${label} <span class="need">Needs you</span><span class="ok">${I.check}</span></label><input id="${id}" value="" placeholder="${esc(ph)}"><div class="hint">${esc(why)}</div></div>`;

  function renderStep1() {
    setWork(`
      <p class="kicker">Step 1 of 3</p>
      <h1>Your application</h1>
      <p class="lede">Start with your email. Applied with CareerGPT before? Your resume and answers load in one step. New here? Upload your resume and the form fills itself. <b>About 2 minutes.</b></p>

      <section class="sec" id="sec-email">
        <div class="sec-h"><div class="sec-title">Email</div><span class="tag accent" id="email-tag">Start here</span></div>
        <div id="email-box">
          <div class="f" id="f-start-w"><label for="f-start">Email</label>
            <div class="email-in"><input id="f-start" type="email" inputmode="email" autocomplete="email" placeholder="you@example.com"><span class="lookup" id="lookup"></span></div>
            <div class="hint">${esc(W.email)}</div>
            <div class="hint proto">Prototype: ${esc(D.saved.email)} is a returning candidate. Any other address is new.</div>
          </div>
        </div>
      </section>

      <section class="sec" id="sec-unlock" hidden>
        <div class="sec-h"><div class="sec-title">${I.shield} Unlock your saved details</div><span class="tag accent" id="unlock-tag">Needs you</span></div>
        <div id="unlock-box"></div>
      </section>

      <section class="sec" id="sec-resume" hidden>
        <div class="sec-h"><div class="sec-title">Resume</div><span class="tag accent" id="resume-tag">Start here</span></div>
        <div id="resume-box">
          <div class="drop" id="drop" tabindex="0" role="button" aria-label="Upload your resume">
            <span class="drop-ic">${I.upload}</span>
            <b>Click to upload or drag and drop</b>
            <small>PDF, DOC or DOCX, up to 10 MB</small>
          </div>
          <div class="hint">${esc(W.resume)} <button class="btn-text" type="button" data-sample>Prototype: use a sample resume</button> · <button class="btn-text" type="button" data-sample-nophone>or one with no phone number</button></div>
        </div>
      </section>

      <div id="form-rest" class="form-rest is-dim">
      <section class="sec">
        <div class="sec-h"><div class="sec-title">Contact</div><span class="tag" data-fill-tag>From your resume</span></div>
        <div class="grid2">
          ${field("f-first", "First name", W.first, "Jane")}
          ${field("f-last", "Last name", W.last, "Doe")}
          ${field("f-email", "Email", W.email, "you@example.com")}
          ${field("f-phone", "Phone", W.phone, "(555) 123-4567")}
          <div class="span2">${field("f-backup", "Backup email", W.backup, "A second address")}</div>
        </div>
      </section>

      <section class="sec">
        <div class="sec-h"><div class="sec-title">Address</div><span class="tag" data-fill-tag>From your resume</span></div>
        <div class="grid2">
          <div class="span2">${field("f-street", "Street address", W.street, "Street and number")}</div>
          ${field("f-city", "City", W.city, "City")}
          ${sel("f-state", ["California", "Texas", "Arizona", "Nevada", "Oregon"], "", W.state, "State")}
          ${field("f-zip", "ZIP code", W.zip, "5 digits")}
        </div>
      </section>

      <section class="sec">
        <div class="sec-h"><div class="sec-title">Background</div><span class="tag" data-fill-tag>From your resume</span></div>
        <div class="grid2">
          ${field("f-title", "Current job title", W.title, "e.g. Associate Dentist")}
          ${field("f-grad", "Dental school graduation year", W.grad, "YYYY")}
          <div class="span2">${sel("f-school", [C.school, "University of the Pacific, Arthur A. Dugoni School of Dentistry", "UCLA School of Dentistry", "Loma Linda University School of Dentistry"], "", W.school, "Dental institution")}</div>
        </div>
      </section>

      <section class="sec" id="sec-pref">
        <div class="sec-h"><div class="sec-title">Preferences</div><span class="tag" id="pref-tag">Not on a resume</span></div>
        <div class="grid2">
          <div class="f" id="f-locpref-w"><label for="f-locpref">First location preference <span class="need">Needs you</span><span class="ok">${I.check}</span></label>
            <select id="f-locpref"><option value="">Choose a city</option>${LOC.map(o => `<option value="${o.value}">${o.value}, TX</option>`).join("")}</select>
            <div class="hint">${esc(W.locpref)}</div>
          </div>
          <div class="f" id="f-relocate-w"><label>Open to relocating anywhere? <span class="need">Needs you</span><span class="ok">${I.check}</span></label>
            <div class="seg" id="f-relocate"><button type="button" data-v="yes">Yes</button><button type="button" data-v="no">No</button></div>
            <div class="hint">${esc(W.relocate)}</div>
          </div>
        </div>
      </section>

      <section class="sec" id="sec-eeo">
        <div class="sec-h"><div class="sec-title">Voluntary self-identification</div><span class="tag">Optional</span></div>
        <div class="eeo-summary"><span>Gender, race, disability and veteran status are all set to <b>Prefer not to say</b>. CareerGPT never guesses these.</span><button class="btn-text" type="button" id="eeo-edit">Edit</button></div>
        <div class="eeo-body">
          <div class="grid2">
            ${sel("f-gender", [...EEO, "Male", "Female", "Non-binary"], EEO[0], "", "Gender")}
            ${sel("f-race", [...EEO, "Asian", "Black or African American", "Hispanic or Latino", "White", "Two or more races", "Other"], EEO[0], "", "Race / ethnicity")}
            ${sel("f-disability", [...EEO, "Yes, I have a disability", "No, I don't have a disability"], EEO[0], "", "Disability status")}
            ${sel("f-veteran", [...EEO, "I am a veteran", "I am not a veteran"], EEO[0], "", "Veteran status")}
          </div>
          <div class="hint" style="margin-top:10px">${esc(W.eeo)}</div>
        </div>
      </section>
      </div>

      <p class="consent">By submitting, you agree to an AI agent submitting this application on West Alamo Dental Care's careers site, and to the <a href="#" data-toast="Terms of service (prototype)">terms of service</a> and <a href="#" data-toast="Privacy policy (prototype)">privacy policy</a>.</p>
    `);
    renderCta1();
    bindEmailStart();
    const drop = $("#drop");
    drop.addEventListener("click", openFilePicker);
    drop.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openFilePicker(); } });
    ["dragenter", "dragover"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
    ["dragleave", "drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("over"); }));
    drop.addEventListener("drop", e => { const f = e.dataTransfer.files && e.dataTransfer.files[0]; onResume(f ? f.name : C.resume); });
    $$("[data-sample]").forEach(b => b.addEventListener("click", () => { state.noPhone = false; onResume(C.resume); }));
    $$("[data-sample-nophone]").forEach(b => b.addEventListener("click", () => { state.noPhone = true; onResume(C.resume); }));
    ["phone", "backup"].forEach(k => $("#" + FIELDS[k].id).addEventListener("blur", e => { const v = e.target.value.trim(); if (v && !e.target.readOnly) fieldFeedback(k, v, "form"); }));
    $("#f-locpref").addEventListener("change", e => { if (e.target.value) setAnswer("locpref", e.target.value, "form"); });
    $$("#f-relocate button").forEach(b => b.addEventListener("click", () => setAnswer("relocate", b.dataset.v, "form")));
    $$("#form-rest input, #form-rest select").forEach(el => el.addEventListener("input", updateProgress));
    $("#eeo-edit").addEventListener("click", openEeo);
    bindToasts();
    setTimeout(() => { const i = $("#f-start"); if (i && !state.identity) i.focus(); }, 350);
  }

  /* Email lookup as they type: a short check, then "Welcome back" or "New here" inside the field. */
  function bindEmailStart() {
    const inp = $("#f-start"), look = $("#lookup");
    let t = null;
    const check = () => {
      const v = inp.value.trim();
      clearTimeout(t); state.lookup = null; renderCta1();
      if (!EMAIL_RE.test(v)) { look.innerHTML = ""; return; }
      look.innerHTML = `<span class="think"><span class="tdot"></span></span>`;
      t = setTimeout(() => {
        state.lookup = isKnownEmail(v) ? "returning" : "new";
        look.innerHTML = state.lookup === "returning" ? `<span class="tag dark">Welcome back</span>` : `<span class="tag">New here</span>`;
        renderCta1();
      }, reduce ? 10 : 700);
    };
    inp.addEventListener("input", check);
    inp.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); if (state.lookup) startWithEmail(); } });
  }

  async function startWithEmail(fromChat) {
    const inp = $("#f-start"); if (!inp) return;
    const v = inp.value.trim();
    if (!EMAIL_RE.test(v) || state.identity) return;
    if (textAsk.key === "start") endTextAsk();
    state.identity = state.lookup || (isKnownEmail(v) ? "returning" : "new");
    state.email = v;
    $("#f-email").value = v; $("#f-email-w").classList.add("done");
    $("#email-box").innerHTML = `<div class="resume"><div class="ic">${I.mail}</div><div><div class="nm">${esc(v)}</div><div class="sub">${state.identity === "returning" ? "Welcome back, your saved details are ready to unlock" : "New here"}</div></div><button class="btn-text act" type="button" id="email-change">Change</button></div>`;
    $("#email-tag").textContent = "Done"; $("#email-tag").classList.remove("accent");
    $("#email-change").addEventListener("click", changeEmail);
    if (fromChat !== true) user(v);
    if (state.identity === "new") {
      $("#sec-resume").hidden = false;
      renderCta1();
      const row = chipRow([{ value: "upload", label: "Upload resume" }, { value: "hand", label: "I'll fill it in by hand" }], o => o.value === "upload" ? openFilePicker() : startByHand());
      state.startRow = row;
      const sam = document.createElement("div"); sam.className = "proto-links";
      sam.innerHTML = `<span>Prototype:</span> <button type="button" class="btn-text" data-s="1">use a sample resume</button> · <button type="button" class="btn-text" data-s="0">sample with no phone number</button>`;
      sam.querySelectorAll("button").forEach(b => b.addEventListener("click", () => { state.noPhone = b.dataset.s === "0"; onResume(C.resume); }));
      const wrapC = document.createElement("div"); wrapC.append(row, sam);
      await agent("New here, welcome. Upload your resume and I'll fill most of this form from it. You only check the answers that need you.", { think: 700, thinkLabel: "Looking you up…", card: wrapC });
      return;
    }
    state.otpMode = "unlock"; state.otpChannel = "sms";
    state.maskedPhone = maskPhone(D.saved.profile.phone); state.maskedEmail = maskEmail(v);
    $("#sec-unlock").hidden = false;
    $("#unlock-box").innerHTML = otpHtml();
    bindOtp(onUnlocked);
    renderCta1();
    await agent(`Welcome back. You've applied with me before, so I texted a code to ${state.maskedPhone}. Enter it and I'll load your resume and the ${D.saved.answerCount} answers from your last application.`, { think: 900, thinkLabel: "Looking you up…", meta: "Found your saved details in 1s" });
    const first = $("#otp input"); if (first && !isMobile()) first.focus();
    askCode();
  }
  function changeEmail() {
    if (state.formActive || state.unlocked) { toast("Restart the prototype to use a different email"); return; }
    state.identity = null; state.lookup = null; state.email = null;
    renderStep1();
    agent("Sure, which email should I use?", { think: 250 });
  }

  /* Returning candidate, after the code: everything loads, the resume asks to be checked. */
  async function onUnlocked() {
    state.verified = true; state.unlocked = true; state.formActive = true; state.filled = true;
    Object.assign(state.answers, D.saved.answers);
    const es = $("#email-box .sub"); if (es) es.textContent = "Welcome back";
    $("#sec-unlock").innerHTML = `<div class="sec-h"><div class="sec-title">${I.shield} Verified by text</div><span class="tag">Done</span></div><p class="hint" style="font-size:14px;color:var(--t2);margin:0">That's the only code you'll enter. It also covers sending the applications at the end.</p>`;
    $("#sec-resume").hidden = false;
    renderSavedResume();
    $("#form-rest").classList.remove("is-dim");
    $$("[data-fill-tag]").forEach(t => { t.textContent = "Saved from your last application"; });
    renderCta1();
    const P = D.saved.profile;
    const seq = [["f-first", P.first], ["f-last", P.last], ["f-phone", P.phone], ["f-backup", P.backupEmail], ["f-street", P.street], ["f-city", P.city], ["f-state", P.state], ["f-zip", P.zip], ["f-title", P.title], ["f-school", P.school], ["f-grad", P.gradYear], ["f-locpref", P.locpref]];
    const fillAll = (async () => {
      for (const [id, v] of seq) {
        const el = $("#" + id); el.value = v;
        const w = el.closest(".f"); w.classList.remove("flash"); void w.offsetWidth; w.classList.add("flash", "done");
        updateProgress();
        await wait(70);
      }
      state.a.backup = P.backupEmail; state.a.locpref = P.locpref; state.a.relocate = P.relocate;
      $$("#f-relocate button").forEach(b => b.classList.toggle("on", b.dataset.v === P.relocate));
      $("#f-relocate-w").classList.add("done");
      updateProgress();
    })();
    const card = document.createElement("div"); card.className = "mcard";
    card.innerHTML = `<ul>
      <li>${I.check}<span><b>Resume</b> from ${esc(fmtDate(D.saved.resume.uploaded))}, your application to ${esc(D.saved.resume.from)}</span></li>
      <li>${I.check}<span><b>Contact, address and background</b></span></li>
      <li>${I.check}<span><b>Preferences</b> ${esc(P.locpref)} first, open to relocating</span></li>
      <li>${I.check}<span><b>Answer bank</b> Texas license, start date, years of experience</span></li>
    </ul>`;
    await agent(`Loaded: your resume from ${fmtDate(D.saved.resume.uploaded)} and ${D.saved.answerCount} answers from your last application.`, { until: fillAll, thinkLabel: "Loading your saved details…", meta: "Loaded your saved details in 1s", card });
    const row = chipRow([{ value: "use", label: "Use it" }, { value: "preview", label: "Preview first" }, { value: "replace", label: "Replace" }], o => { if (o.value === "use") confirmResume("chat"); else if (o.value === "preview") openPreview(); else openFilePicker(); });
    state.resumeRow = row;
    await agent(`One thing I can't check for you: is that resume still current? It's ${ageText(daysSince(D.saved.resume.uploaded))} old.`, { think: 400, chips: row });
    const loc = await ask("locpref", `Last time your first location was ${P.locpref}. This job's in San Antonio. Switch, or keep ${P.locpref}?`, [{ value: "San Antonio", label: "San Antonio" }, { value: P.locpref, label: `Keep ${P.locpref}` }], { onPick: o => setAnswer("locpref", o.value, "chat"), think: 400 });
    await agent(state.resumeConfirmed ? "Everything's ready. Submit when it looks right to you." : "Everything else is ready. Confirm the resume and submit.", { think: 400, chips: reviewChips("Review and submit") });
  }
  function renderSavedResume() {
    const R = D.saved.resume, age = daysSince(R.uploaded), stale = age > 90;
    const tag = $("#resume-tag"); tag.textContent = "Still current?"; tag.classList.add("accent");
    $("#resume-box").innerHTML = `
      <div class="saved-resume${stale ? " stale" : ""}" id="saved-resume">
        <div class="sr-top"><div class="ic">${I.doc}</div><div class="sr-meta"><div class="nm">${esc(R.name)}</div><div class="sub">Uploaded ${esc(fmtDate(R.uploaded))} · ${esc(ageText(age))} ago · from your application to ${esc(R.from)}</div><div class="sr-chips">${D.saved.summary.map(x => `<span>${esc(x)}</span>`).join("")}</div></div></div>
        <div class="sr-q">${stale ? `This one is ${esc(ageText(age))} old. Still current?` : "Still current? Check it before it's attached."}</div>
        <div class="sr-actions">
          <button class="btn btn-secondary" type="button" id="resume-preview">${I.eye} Preview</button>
          <button class="btn ${stale ? "btn-secondary" : "btn-primary"}" type="button" id="resume-use">Use this resume</button>
          <button class="btn ${stale ? "btn-primary" : "btn-text"}" type="button" id="resume-replace">${stale ? `${I.upload} Replace` : "Replace"}</button>
        </div>
      </div>`;
    $("#resume-preview").addEventListener("click", openPreview);
    $("#resume-use").addEventListener("click", () => confirmResume("form"));
    $("#resume-replace").addEventListener("click", openFilePicker);
  }
  function confirmResume(source) {
    if (state.resumeConfirmed) return;
    state.resumeConfirmed = true; state.resume = D.saved.resume.name;
    if (state.resumeRow) { const b = state.resumeRow.querySelector('.chip[data-value="use"]'); if (b) markChip(state.resumeRow, b); }
    const R = D.saved.resume;
    $("#resume-box").innerHTML = `<div class="resume"><div class="ic">${I.doc}</div><div><div class="nm">${esc(R.name)}</div><div class="sub">Uploaded ${esc(fmtDate(R.uploaded))} · confirmed as current</div></div><span class="act"><button class="btn-text" type="button" id="resume-preview">Preview</button> · <button class="btn-text" type="button" id="resume-replace">Replace</button></span></div>`;
    $("#resume-preview").addEventListener("click", openPreview);
    $("#resume-replace").addEventListener("click", openFilePicker);
    const tag = $("#resume-tag"); tag.textContent = "Confirmed"; tag.classList.remove("accent");
    closePreview();
    renderCta1(); updateProgress();
    if (source !== "chat") { user("Use it"); }
    agent("Resume confirmed.", { think: 200 });
  }

  /* Resume preview: a drawer on desktop, the whole screen on a phone. The document is rendered, not a picture of it. */
  function resumeDocHtml() {
    const R = D.resumeDoc;
    return `<div class="page">
        <div class="pg-head"><div class="pg-name">${esc(R.name)}</div><div class="pg-title">${esc(R.title)}</div><div class="pg-contact">${esc(R.contact)}</div></div>
        <h4>Summary</h4><p>${esc(R.summary)}</p>
        <h4>Experience</h4>
        ${R.experience.map(e => `<div class="pg-item"><div class="pg-row"><b>${esc(e.role)}</b><span>${esc(e.dates)}</span></div><div class="pg-org">${esc(e.org)}</div><ul>${e.bullets.map(b => `<li>${esc(b)}</li>`).join("")}</ul></div>`).join("")}
        <div class="pg-num">1 of 2</div>
      </div>
      <div class="page">
        <h4>Education</h4>
        ${R.education.map(e => `<div class="pg-item"><div class="pg-row"><b>${esc(e.degree)}</b><span>${esc(e.year)}</span></div><div class="pg-org">${esc(e.org)}</div></div>`).join("")}
        <h4>Licenses and certifications</h4><ul>${R.licenses.map(l => `<li>${esc(l)}</li>`).join("")}</ul>
        <h4>Skills</h4><p>${esc(R.skills)}</p>
        <div class="pg-num">2 of 2</div>
      </div>`;
  }
  function openPreview() {
    const R = D.saved.resume;
    $("#pv-name").textContent = R.name;
    $("#pv-sub").textContent = `Uploaded ${fmtDate(R.uploaded)} · ${ageText(daysSince(R.uploaded))} ago · ${R.pages} pages`;
    $("#pv-body").innerHTML = resumeDocHtml();
    $("#pv-foot").innerHTML = state.resumeConfirmed
      ? `<button class="btn btn-secondary" type="button" id="pv-replace">Replace</button><button class="btn btn-primary" type="button" id="pv-done">Done</button>`
      : `<button class="btn btn-secondary" type="button" id="pv-replace">Replace</button><button class="btn btn-primary" type="button" id="pv-use">Use this resume</button>`;
    $("#pv-replace").addEventListener("click", () => { closePreview(); openFilePicker(); });
    const u = $("#pv-use"); if (u) u.addEventListener("click", () => confirmResume("form"));
    const d = $("#pv-done"); if (d) d.addEventListener("click", closePreview);
    $("#preview").classList.add("open"); $("#pv-backdrop").classList.add("show"); $("#preview").setAttribute("aria-hidden", "false");
    $("#pv-body").scrollTop = 0;
  }
  function closePreview() { $("#preview").classList.remove("open"); $("#pv-backdrop").classList.remove("show"); $("#preview").setAttribute("aria-hidden", "true"); }
  $("#pv-close").addEventListener("click", closePreview);
  $("#pv-backdrop").addEventListener("click", closePreview);

  const daysSince = iso => Math.max(0, Math.round((Date.now() - new Date(iso + "T12:00:00")) / 86400000));
  const fmtDate = iso => new Date(iso + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" });
  const ageText = d => d < 1 ? "today" : d === 1 ? "1 day" : d < 60 ? `${d} days` : `${Math.round(d / 30)} months`;

  function renderCta1() {
    if (!state.identity) {
      setCta(`<div class="cta-in"><div class="cta-meta"><span>Your email first. Everything else follows from it.</span></div>
        <div class="cta-actions"><button class="btn btn-primary" type="button" id="email-go"${state.lookup ? "" : " disabled"}>Continue ${I.arrow}</button></div></div>`);
      $("#email-go").addEventListener("click", startWithEmail);
      return;
    }
    if (state.identity === "returning" && !state.unlocked) {
      setCta(`<div class="cta-in"><div class="cta-meta"><span>Enter the code to load your saved details</span></div><div class="cta-actions"><button class="btn btn-primary" type="button" disabled>${I.shield} Unlock</button></div></div>`);
      return;
    }
    if (!state.formActive) {
      setCta(`<div class="cta-in"><div class="cta-meta"><span>19 questions. Most of them fill themselves from your resume.</span></div>
        <div class="cta-actions"><button class="btn btn-ghost" type="button" id="byhand">Fill in by hand</button><button class="btn btn-primary" type="button" id="upload-cta">${I.upload} Upload resume</button></div></div>`);
      $("#upload-cta").addEventListener("click", openFilePicker);
      $("#byhand").addEventListener("click", startByHand);
      return;
    }
    if (state.processing) {
      setCta(`<div class="cta-in"><div class="cta-meta"><span>Reading your resume</span></div><div class="cta-actions"><button class="btn btn-primary" type="button" disabled>Filling in…</button></div></div>`);
      return;
    }
    const needConfirm = state.identity === "returning" && !state.resumeConfirmed;
    setCta(`<div class="cta-in"><div class="cta-meta"><div class="bar"><i id="bar-i" style="width:0%"></i></div><span><b id="ans-n">0</b> of 19 answered${needConfirm ? " · confirm your resume" : ""}</span></div>
      <div class="cta-actions"><button class="btn btn-primary" type="button" id="submit1"${needConfirm ? " disabled" : ""}>Submit application ${I.arrow}</button></div></div>`);
    $("#submit1").addEventListener("click", submitFirst);
    updateProgress();
  }

  function openFilePicker() { $("#resume-file").click(); }
  $("#resume-file").addEventListener("change", e => { const f = e.target.files && e.target.files[0]; if (f) onResume(f.name); e.target.value = ""; });
  $("#plus").addEventListener("click", () => { if (state.step === 1 && state.identity && !state.resume) openFilePicker(); else toast("Attachments (prototype)"); });

  function startByHand() {
    if (state.formActive) return;
    state.formActive = true; state.filled = true;
    $("#form-rest").classList.remove("is-dim");
    $$("[data-fill-tag]").forEach(t => { t.textContent = "Type your answers"; });
    ["f-backup", "f-locpref", "f-relocate"].forEach(id => $(`#${id}-w`).classList.add("needs"));
    renderCta1();
    markStart("hand");
    user("I'll fill it in by hand");
    agent("No problem. The form is open on the right, every answer says why it's needed. I'll check it as you go, and you can upload a resume later with the + button.", { think: 500 });
    $("#f-first").focus();
  }

  function updateProgress() {
    if (!state.filled) return;
    const fields = $$("#form-rest input, #form-rest select");
    let n = fields.filter(f => f.value && f.value.trim()).length + (state.a.relocate ? 1 : 0) + (state.resume ? 1 : 0);
    const an = $("#ans-n"); if (an) an.textContent = n; syncRevBar();
    const bar = $("#bar-i"); if (bar) bar.style.width = Math.min(100, n / 19 * 100) + "%";
    const left = ["backup", "locpref", "relocate"].filter(k => !state.a[k]).length;
    const tag = $("#pref-tag"); if (tag) { tag.textContent = left ? `${left} need${left === 1 ? "s" : ""} you` : "Done"; tag.classList.toggle("accent", left > 0); }
    if (n >= 19) { const b = $("#submit1"); if (b && !b.disabled) b.classList.add("pulse"); }
  }

  function setAnswer(key, value, source) {
    state.a[key] = value;
    const w = $(`#f-${key}-w`);
    if (key === "locpref") $("#f-locpref").value = value;
    if (key === "backup") $("#f-backup").value = value;
    if (key === "relocate") $$("#f-relocate button").forEach(b => b.classList.toggle("on", b.dataset.v === value));
    if (w) { inChat(w, false); w.classList.remove("needs", "flash"); void w.offsetWidth; w.classList.add("done", "flash"); if (source === "chat") w.scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" }); }
    if (source === "form" && state.pending[key]) state.pending[key].answer(value);
    updateProgress();
  }
  function openEeo() { const s = $("#sec-eeo"); if (!s) return; s.classList.add("open"); s.scrollIntoView({ block: "start", behavior: reduce ? "auto" : "smooth" }); }
  function focusField(id) { const el = $("#" + id); if (!el) return; el.closest(".f").classList.add("needs"); el.scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" }); el.focus(); }

  /* Resume: processing card (6s, four emoji stages, progress bar), then fields fill one by one. */
  function runProcessing(name) {
    state.resume = null; state.processing = true; state.formActive = true;
    const tag = $("#resume-tag"); tag.textContent = "Reading"; tag.classList.remove("accent");
    const box = $("#resume-box");
    box.innerHTML = `<div class="proc" id="proc"><div class="proc-emoji" id="proc-e">${STAGES[0].e}</div><div class="proc-t" id="proc-t">${STAGES[0].t}</div><div class="proc-bar"><i id="proc-i"></i></div><div class="proc-pct" id="proc-p">0% complete</div></div>
      <div class="hint">${esc(name)} · ${esc(W.resume)}</div>`;
    renderCta1();
    const total = reduce ? 10 : 6200, start = performance.now();
    return new Promise(resolve => {
      let stage = 0;
      const tick = () => {
        const p = Math.min(1, (performance.now() - start) / total);
        const s = Math.min(3, Math.floor(p * 4));
        if (s !== stage) { stage = s; const e = $("#proc-e"); e.textContent = STAGES[s].e; e.classList.remove("pop"); void e.offsetWidth; e.classList.add("pop"); $("#proc-t").textContent = STAGES[s].t; }
        $("#proc-i").style.width = (p * 100) + "%";
        $("#proc-p").textContent = Math.round(p * 100) + "% complete";
        if (p < 1) requestAnimationFrame(tick); else { state.resume = name; state.processing = false; resolve(); }
      };
      requestAnimationFrame(tick);
    });
  }
  async function fillFromResume() {
    const box = $("#resume-box");
    box.innerHTML = `<div class="resume"><div class="ic">${I.doc}</div><div><div class="nm">${esc(state.resume)}</div><div class="sub">Uploaded just now · 11 answers filled from it</div></div><button class="btn-text act" type="button" data-change>Change</button></div>`;
    $("#resume-tag").textContent = "Uploaded";
    $("#resume-tag").classList.remove("accent");
    $("[data-change]").addEventListener("click", openFilePicker);
    $("#form-rest").classList.remove("is-dim");
    state.filled = true;
    if (state.identity === "returning") state.resumeConfirmed = true;
    renderCta1();
    const seq = [["f-first", C.first], ["f-last", C.last], ["f-email", $("#f-email").value || C.email], ["f-phone", state.noPhone ? "" : C.phone], ["f-street", C.street], ["f-city", C.city], ["f-state", C.state], ["f-zip", C.zip], ["f-title", C.title], ["f-school", C.school], ["f-grad", C.gradYear]];
    for (const [id, v] of seq) {
      if (!v && id === "f-phone") { inChat($("#f-phone-w"), true); continue; }
      const el = $("#" + id); el.value = v;
      const w = el.closest(".f"); w.classList.remove("flash"); void w.offsetWidth; w.classList.add("flash", "done");
      if (id === "f-street") w.scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" });
      updateProgress();
      await wait(120);
    }
    ["backup", "locpref", "relocate"].forEach(k => { if (!state.a[k]) inChat($(`#f-${k}-w`), true); });
    updateProgress();
    if (!isMobile()) $("#sec-resume").scrollIntoView({ block: "start", behavior: reduce ? "auto" : "smooth" });
  }

  async function onResume(name) {
    if (state.processing) return;
    const replacing = state.identity === "returning";
    if (replacing && state.resumeRow) { const b = state.resumeRow.querySelector('.chip[data-value="replace"]'); if (b) markChip(state.resumeRow, b); }
    closePreview();
    markStart("upload");
    user(name, { attachment: true });
    const done = runProcessing(name).then(fillFromResume);
    if (replacing) {
      await agent("New resume in. I re-read it and updated the 11 answers it covers; everything else stays as it was.", { until: done, thinkLabel: "Reading your resume…", meta: "Read your resume in 6s" });
      await agent("Everything's ready. Submit when it looks right to you.", { think: 300 });
      return;
    }
    const card = document.createElement("div"); card.className = "mcard";
    card.innerHTML = `<ul>
      <li>${I.check}<span><b>${state.noPhone ? "Name and email" : "Name, email and phone"}</b></span></li>
      <li>${I.check}<span><b>Address</b> 2120 Pine St, San Francisco</span></li>
      <li>${I.check}<span><b>Associate Dentist</b>, DDS UCSF 2016</span></li>
      <li>${I.check}<span><b>Voluntary questions</b> set to "Prefer not to say"</span></li>
    </ul>`;
    const nF = state.noPhone ? 10 : 11, nN = state.noPhone ? 4 : 3;
    await agent(`Done. I filled ${nF} of 19 answers from your resume and set the 4 voluntary ones to "Prefer not to say". ${nN} aren't on a resume, so they need you.`, { until: done, thinkLabel: "Reading your resume…", meta: "Read your resume in 6s", card });
    if (state.noPhone) await askField("phone", "Your resume doesn't list a phone number, and West Alamo needs one to call you about interviews. What's the best number?");
    const be = await ask("backup", "First: West Alamo asks for a backup email in case your main one is already registered with them. Your resume also lists " + C.backupEmail + ". Use that?", [{ value: C.backupEmail, label: "Use " + C.backupEmail }, { value: "other", label: "Type a different one" }], { onPick: o => { if (o.value !== "other") setAnswer("backup", o.value, "chat"); }, think: 400 });
    if (be.value === "other") await askField("backup", "Sure. What address should I use?", { think: 300 });
    const loc = await ask("locpref", "West Alamo asks for a first location preference. The job's in San Antonio and your resume says San Francisco. What should I put?", LOC, { onPick: o => setAnswer("locpref", o.value, "chat"), think: 400 });
    await agent(`Done, ${loc.value} it is.`, { think: 300 });
    const rel = await ask("relocate", "And are you open to relocating anywhere?", [{ value: "yes", label: "Yes" }, { value: "no", label: "No" }], { onPick: o => setAnswer("relocate", o.value, "chat"), think: 300 });
    await agent(rel.value === "yes" ? "Noted, I've put Yes." : "Noted, I've put No.", { think: 300 });
    await agent("The voluntary questions (gender, race, disability, veteran status) are optional and only used for the employer's equal-opportunity reporting. I never guess them.", { think: 400, links: [{ label: "Open them if you'd like to answer", onClick: openEeo }] });
    await agent("Everything's ready. Check it over and submit when it looks right to you.", { think: 400, chips: reviewChips("Review and submit") });
  }

  async function runStep1Chat() {
    const note = document.createElement("div"); note.className = "proto-note"; note.textContent = `Prototype: ${D.saved.email} is a returning candidate. Any other address is new.`;
    await agent("Hi, I'm CareerGPT. I fill job applications so you don't have to. Type your email below to start: if you've applied with me before, your resume and answers load in one step. If not, I'll read your resume and fill the form from it.", { think: 700, card: note });
    if (!state.identity) { Object.assign(textAsk, { key: "start", handle: startEmailFromChat, tries: 0 }); setAwaiting(true, "Type your email…", "email"); }
  }
  /* The form (drop zone, sample link, CTA) can answer the chat's first question too: mark the matching chip. */
  function markStart(value) { const row = state.startRow; if (!row) return; const b = row.querySelector(`.chip[data-value="${value}"]`); if (b) markChip(row, b); }

  function shakeField(key) {
    const w = $(`#${key}-w`) || $(`#f-${key}-w`); if (!w) return;
    w.classList.add("needs");
    w.scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" });
    w.classList.remove("shake"); void w.offsetWidth; w.classList.add("shake");
  }
  async function submitFirst() {
    const required = ["f-first", "f-last", "f-email", "f-phone", "f-backup", "f-street", "f-city", "f-state", "f-zip", "f-title", "f-school", "f-grad", "f-locpref"];
    const missing = required.filter(id => !($("#" + id).value || "").trim());
    if (!state.a.relocate) missing.push("f-relocate");
    if (missing.length) {
      shakeField(missing[0]);
      agent(missing.length === 1 ? "One thing first: the highlighted answer in the form." : `${missing.length} answers are still empty. I've highlighted the first one.`, { think: 250 });
      return;
    }
    for (const k of ["phone", "backup"]) { const v = FIELDS[k].validate($("#" + FIELDS[k].id).value); if (!v.ok) { shakeField(k === "phone" ? "phone" : "backup"); fieldFeedback(k, $("#" + FIELDS[k].id).value, "submit"); return; } }
    const pv = validatePhone($("#f-phone").value);
    if (state.identity === "returning" && !state.resumeConfirmed) {
      const sr = $("#saved-resume"); if (sr) { sr.scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" }); sr.classList.remove("shake"); void sr.offsetWidth; sr.classList.add("shake"); }
      agent("One thing first: confirm the resume. It's the one answer I can't check for you.", { think: 250 });
      return;
    }
    const btn = $("#submit1"); btn.disabled = true; btn.innerHTML = "Submitting…";
    state.email = ($("#f-email").value || "").trim() || C.email;
    state.phone = pv.value;
    agent("Submitting to West Alamo Dental Care.", { think: 250 });
    await runChecklist("Submitting your application", ["Opening West Alamo Dental Care's careers site", "Filling 19 answers", `Attaching ${state.resume || "your resume"}`, "Submitting"]);
    state.pref.area = "sa"; state.pref.practice = "any"; resetSelection();
    state.sent = [D.firstJob];
    collapseThread("Apply · sent to West Alamo");
    setStep(2); renderStep2(); runStep2Chat();
  }
  async function runChecklist(title, items) {
    openReview();
    setWork(`<div class="send-card"><h2>${esc(title)}</h2><ul class="steps">${items.map(t => `<li><span class="dot">${I.check}</span><span>${esc(t)}</span></li>`).join("")}</ul></div>`);
    setCta(`<div class="cta-in"><div class="cta-meta"><span>Working on the employer's site</span></div><div class="cta-actions"><button class="btn btn-primary" disabled>Submitting…</button></div></div>`);
    for (const li of $$(".steps li")) { li.classList.add("doing"); await wait(620); li.classList.remove("doing"); li.classList.add("done"); }
    await wait(350);
  }

  /* ================= STEP 2: add more jobs ================= */
  const areaOpt = v => D.areaOptions.find(o => o.value === v);
  const practiceOpt = v => D.practiceOptions.find(o => o.value === v);
  const poolFor = (area, practice) => { const a = areaOpt(area || "sa"), p = practiceOpt(practice || "any"); return D.jobs.filter(j => a.test(j) && p.test(j)); };
  const pool = () => poolFor(state.pref.area, state.pref.practice);
  const areaCounts = () => D.areaOptions.map(o => ({ value: o.value, label: o.label, count: poolFor(o.value, state.pref.practice).length }));
  const practiceCounts = () => D.practiceOptions.map(o => ({ value: o.value, label: o.label, count: poolFor(state.pref.area, o.value).length }));
  /* Effective tier: extra questions already answered (this session, or the answer bank of a returning candidate) don't count,
     so a "quick" job becomes 1-click once its questions are in the bank. */
  const leftQ = j => j.extra.filter(k => !answered(D.questions[k]));
  const tierOf = j => { const n = leftQ(j).length; return n === 0 ? "ready" : n <= 3 ? "quick" : "long"; };
  const bankBoost = p => p.filter(j => D.tierOf(j) !== "ready" && tierOf(j) === "ready").length;
  const groupsFor = p => { const g = { ready: [], quick: [], long: [] }; p.forEach(j => g[tierOf(j)].push(j)); return g; };
  const selectedJobs = () => D.jobs.filter(j => state.selected.has(j.id));
  function unionQuestions(jobs) { const ids = new Set(); jobs.forEach(j => j.extra.forEach(q => ids.add(q))); return Object.keys(D.questions).filter(k => ids.has(k)).map(k => D.questions[k]); }

  /* Daily limit: 10 applications a day, the first one counts. Step 2 can add at most capLeft(); the rest of the eligible
     roles (1-click + quick) wait for tomorrow's email. Preselection takes the best capLeft() by rank. */
  const DAILY_GOAL = 10;
  const capLeft = () => Math.max(0, DAILY_GOAL - state.sent.length);
  const rankJob = j => (tierOf(j) === "ready" ? 0 : 1) * 10000 + (j.area === "sa" ? 0 : j.area === "tx" ? 1 : 2) * 1000 + (j.miles ?? 999) - (j.early ? 5 : 0);
  const byRank = (a, b) => rankJob(a) - rankJob(b);
  const eligible = () => pool().filter(j => tierOf(j) !== "long").sort(byRank);
  const queued = () => eligible().filter(j => !state.selected.has(j.id));
  const atCap = () => state.selected.size >= capLeft();
  function resetSelection() { state.selected = new Set(eligible().slice(0, capLeft()).map(j => j.id)); }
  function capToast() { toast(`That's ${DAILY_GOAL} for today. Untick one to swap, or it goes out tomorrow.`); }

  /* choosePref(): from the chat chips or the controls on the right; both stay in sync. */
  function choosePref(key, value, source) {
    const changed = state.pref[key] !== value;
    state.pref[key] = value;
    if (changed) resetSelection();
    renderStep2(changed);
    refreshCounts(state.areaRow, areaCounts());
    refreshCounts(state.practiceRow, practiceCounts());
    if (source === "form" && state.pending[key]) state.pending[key].answer(value);
    if (source === "form" && changed && state.step2Ready) agent(`Updated: ${pool().length} roles ${key === "area" ? areaOpt(value).phrase : practiceOpt(value).label.toLowerCase() === "either" ? "either practice type" : practiceOpt(value).label.toLowerCase()}.${queued().length && atCap() ? ` ${state.selected.size} ticked, today's max; ${queued().length} wait for tomorrow.` : ""}`, { think: 250 });
  }

  const placeText = j => j.city === "San Antonio" ? "San Antonio · same city as the job" : j.state === "TX" ? `${j.city}, TX · ${j.miles} mi away` : `${j.city}, ${j.state}`;
  const practiceText = j => j.practice === "private" ? "Private practice" : "Group practice";
  const qText = j => { const n = leftQ(j).length; return n ? `${n} extra ${plural(n, "question")}${n < j.extra.length ? ` · ${j.extra.length - n} reused` : ""}` : "1-click apply · no extra questions"; };
  const jobRow = (j, on, showQ, tag) => `<div class="job${!on ? " off" : ""}${tag ? " queued" : ""}" data-job="${j.id}">
        <div class="mono">${mono(j.company)}</div>
        <div><div class="jt">${esc(j.company)}</div><div class="jm">${esc(placeText(j))} · ${practiceText(j)}${j.pay ? " · " + esc(j.pay) : ""}${j.early ? ' · <span class="early">Early applicant</span>' : ""}</div>${showQ ? `<div class="jq${j.extra.length ? "" : " ready"}">${qText(j)}</div>` : ""}</div>
        <span class="job-r">${tag ? `<span class="tmrw">${esc(tag)}</span>` : ""}<span class="cb${on ? " on" : ""}">${I.check}</span></span>
      </div>`;

  function prefsHtml() {
    const row = (label, opts, key, cur) => `<div class="pref-row"><span class="pref-label">${label}</span><div class="pref-opts">${opts.map(o => `<button type="button" class="chip${o.value === cur ? " on" : ""}" data-pref="${key}" data-value="${o.value}"><span>${esc(o.label)}</span><span class="n">${o.count}</span></button>`).join("")}</div></div>`;
    return `<div class="prefs">${row("Where", areaCounts(), "area", state.pref.area)}${row("Practice", practiceCounts(), "practice", state.pref.practice)}</div>`;
  }
  function tierHtml(t, jobs) {
    const tier = D.tiers[t];
    if (!jobs.length) return "";
    const on = jobs.filter(j => state.selected.has(j.id)).length;
    const cbState = on === 0 ? "" : on === jobs.length ? "on" : "mixed";
    const qs = unionQuestions(jobs).filter(q => !answered(q));
    const qTags = t === "quick" ? `<div class="tier-q">${qs.map(q => `<span>${esc(q.short || q.label)}</span>`).join("")}</div>` : "";
    const capped = atCap() && t !== "long";
    return `<section class="tier${on === 0 ? " off" : ""}" data-tier="${t}">
      <div class="tier-h">
        <button class="cb ${cbState}" type="button" data-tier-cb="${t}" aria-label="Select all in ${esc(tier.title)}">${I.check}</button>
        <div><div class="tier-title">${esc(tier.title)} <span class="count">${jobs.length}</span></div><div class="tier-blurb">${esc(tier.blurb)}</div>${qTags}</div>
        <button class="btn-text" type="button" data-tier-toggle="${t}">${on === jobs.length ? "Clear" : "Select all"}</button>
      </div>
      ${jobs.map(j => { const sel = state.selected.has(j.id); return jobRow(j, sel, t !== "ready", !sel && capped ? "Tomorrow" : ""); }).join("")}
    </section>`;
  }

  function renderStep2(rerender) {
    const p = pool(), g = groupsFor(p);
    const st = workScroll.scrollTop;
    setWork(`
      <div class="black-card slim">
        <div class="big">${I.check}</div>
        <div><span class="bc-title">Application sent</span><span class="bc-sub">West Alamo Dental Care</span></div>
        <div class="bc-right">Just now</div>
      </div>
      <div class="pool-h"><h2>More roles that fit your resume</h2><span class="live"><b id="live-n">${p.length}</b> ${areaOpt(state.pref.area).phrase}</span></div>
      <p class="why-line">${I.sparkle}<span>Same role as West Alamo, matched to your resume: <b>general dentist</b>, <b>DDS UCSF 2016</b>, <b>10 years</b>. The 1-click ones are ticked first.</span></p>
      ${prefsHtml()}
      <p class="cap-line">${I.shield}<span>Up to <b>${DAILY_GOAL} applications a day</b>. ${state.sent.length} sent, so up to <b>${capLeft()}</b> here${queued().length && atCap() ? `; the other <b>${queued().length}</b> go out first tomorrow` : ""}.</span></p>
      ${["ready", "quick", "long"].map(t => tierHtml(t, g[t])).join("")}
    `);
    renderCta2();
    if (rerender) { workScroll.scrollTop = Math.min(st, 180); const n = $("#live-n"); n.classList.remove("pop"); void n.offsetWidth; n.classList.add("pop"); }
    $$("[data-pref]").forEach(b => b.addEventListener("click", () => choosePref(b.dataset.pref, b.dataset.value, "form")));
    $$("[data-tier-cb]").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); toggleTier(b.dataset.tierCb); }));
    $$("[data-tier-toggle]").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); toggleTier(b.dataset.tierToggle); }));
    $$(".job").forEach(row => row.addEventListener("click", () => toggleJob(row.dataset.job)));
  }
  function rerenderStep2() { const st = workScroll.scrollTop; renderStep2(); workScroll.scrollTop = st; }
  function toggleJob(id) {
    if (state.selected.has(id)) state.selected.delete(id);
    else if (atCap()) { capToast(); const row = $(`.job[data-job="${id}"]`); if (row) { row.classList.remove("shake"); void row.offsetWidth; row.classList.add("shake"); } return; }
    else state.selected.add(id);
    rerenderStep2();
  }
  function toggleTier(t) {
    const jobs = groupsFor(pool())[t].slice().sort(byRank);
    const all = jobs.every(j => state.selected.has(j.id));
    if (all) jobs.forEach(j => state.selected.delete(j.id));
    else { let cut = false; jobs.forEach(j => { if (state.selected.has(j.id)) return; if (atCap()) { cut = true; return; } state.selected.add(j.id); }); if (cut) capToast(); }
    rerenderStep2();
  }
  function renderCta2() {
    const sel = selectedJobs(), qs = unionQuestions(sel).filter(q => !answered(q));
    const mins = qs.length ? Math.max(1, Math.round(qs.length * 0.4)) : 0;
    const meta = sel.length === 0 ? "Pick at least one role to continue" : `<b>${sel.length}</b> selected${atCap() ? " · today's max" : ""} · ${qs.length ? `${qs.length} extra ${plural(qs.length, "question")} · about ${mins} min` : "no extra questions"}`;
    setCta(`<div class="cta-in"><div class="cta-meta"><span>${meta}</span></div>
      <div class="cta-actions"><button class="btn btn-ghost" type="button" id="done-early">I'm done for today</button><button class="btn btn-primary" type="button" id="continue2"${sel.length === 0 ? " disabled" : ""}>${sel.length ? `Continue with ${sel.length} ${plural(sel.length, "job")}` : "Continue"} ${I.arrow}</button></div></div>`);
    $("#continue2").addEventListener("click", goStep3);
    $("#done-early").addEventListener("click", finishEarly);
  }
  async function runStep2Chat() {
    await agent("Sent. West Alamo usually replies by email within a week.", { think: 450 });
    const sa = poolFor("sa", "any").length, us = poolFor("us", "any").length, g0 = groupsFor(pool()), pre = selectedJobs().length, boost = bankBoost(pool());
    const areaP = ask("area", `${sa} more roles around San Antonio fit your resume: ${g0.ready.length} are 1-click apply${boost ? ` (${boost} of them thanks to answers from your last application)` : ""}${g0.quick.length ? `, ${g0.quick.length} need a few quick answers` : ""}. I've ticked ${pre === g0.ready.length + g0.quick.length ? `all ${pre}` : pre}. Look wider?`, areaCounts(), {
      onPick: (o, first) => choosePref("area", o.value, "chat"), until: null, thinkLabel: "Searching roles…", think: 1400, meta: `Searched ${us} roles in 2s`,
    });
    state.areaRow = state.pending.area.row;
    await areaP;
    const pracP = ask("practice", "What kind of practice?", practiceCounts(), { onPick: (o, first) => choosePref("practice", o.value, "chat"), think: 400 });
    state.practiceRow = state.pending.practice.row;
    await pracP;
    await agent(step2Summary(), { think: 500, chips: reviewChips("Review the jobs") });
    state.step2Ready = true;
  }
  /* One line that also explains the daily limit when the pool is bigger than what can go today. */
  function step2Summary() {
    const p = pool(), g = groupsFor(p), k = unionQuestions(g.quick).filter(x => !answered(x)).length, q = queued().length;
    const mix = `${g.ready.length} 1-click apply${g.quick.length ? `, ${g.quick.length} with ${k} short ${plural(k, "answer")}` : ""}`;
    return q && atCap()
      ? `${p.length} match: ${mix}. I've ticked ${state.selected.size}, today's max of ${DAILY_GOAL} with West Alamo. The other ${q} go out first tomorrow.`
      : `${p.length} match: ${mix}. Untick any you don't want.`;
  }

  /* ================= STEP 3: confirm and send ================= */
  function goStep3() {
    const n = selectedJobs().length, first = !state.step3Seen;
    state.step3Seen = true;
    if (first) collapseThread(`Add more jobs · ${n} selected`);
    setStep(3); renderStep3();
    if (first) runStep3Chat(); else agent(`Back on the last step with ${n} ${plural(n, "job")}.`, { think: 250 });
  }
  function qHtml(q) {
    const v = state.answers[q.id];
    const jobsAsking = selectedJobs().filter(j => j.extra.includes(q.id)).length;
    let control = "";
    if (q.kind === "text") control = `<div class="f"><input data-q="${q.id}" value="${esc(v ?? q.prefill ?? "")}" placeholder="${esc(q.placeholder || "")}">${q.note ? `<div class="hint">${esc(q.note)}</div>` : ""}</div>`;
    if (q.kind === "chips") control = `<div class="opt-chips">${q.options.map(o => `<button type="button" class="chip${v === o ? " on" : ""}" data-q="${q.id}" data-v="${esc(o)}">${esc(o)}</button>`).join("")}</div>`;
    if (q.kind === "textarea") control = `<div class="f"><textarea data-q="${q.id}" placeholder="${esc(q.placeholder || "")}">${esc(v ?? "")}</textarea>${q.draft ? `<div class="hint"><button type="button" class="btn-text" data-draft="${q.id}">Draft it from my resume</button> · ${esc(q.note)}</div>` : ""}</div>`;
    return `<div class="q" data-qwrap="${q.id}"><div class="q-h"><div class="q-label">${esc(q.label)}</div><div class="q-meta">Asked by ${jobsAsking} ${plural(jobsAsking, "job")}</div></div>${control}</div>`;
  }
  /* OTP goes to the phone by default (SMS autofills on mobile), with email one tap away. Two modes: "unlock" (returning
     candidate, step 1) and "send" (new candidate, step 3). */
  const maskPhone = p => { const d = String(p).replace(/\D/g, ""); return d.length >= 7 ? `(${d.slice(0, 3)}) •••-${d.slice(-4)}` : "your phone"; };
  const maskEmail = e => String(e).replace(/^(.{2})[^@]*(@.*)$/, (m, a, b) => a + "•".repeat(Math.max(3, m.length - a.length - b.length)) + b);
  const otpDest = () => state.otpChannel === "sms" ? state.maskedPhone : state.maskedEmail;
  const otpCopy = () => {
    const via = state.otpChannel === "sms" ? `texted to <b>${esc(state.maskedPhone)}</b>` : `emailed to <b>${esc(state.maskedEmail)}</b>`;
    if (state.otpMode === "unlock") return `Enter the 6-digit code we ${via}${state.otpChannel === "sms" ? ", the number on your saved profile" : ""}. It unlocks your resume and <b>${D.saved.answerCount} answers</b> from your last application, and it's the only code you'll enter.`;
    const n = selectedJobs().length;
    return `Enter the 6-digit code we ${via}. It confirms it's you before <b>${n} ${plural(n, "application")}</b> go out in your name.`;
  };
  const otpSwitchLabel = () => state.otpChannel === "sms" ? "Get it by email instead" : "Get it by text instead";
  const otpHtml = () => `<div class="otp-card${state.otpMode === "unlock" ? " bare" : ""}" id="otp-card">
        ${state.otpMode === "unlock" ? "" : `<h2>${I.shield} Confirm it's you</h2>`}
        <p id="otp-copy">${otpCopy()}</p>
        <div class="otp" id="otp">${[0, 1, 2, 3, 4, 5].map(i => `<input inputmode="numeric" pattern="[0-9]*" maxlength="1" aria-label="Digit ${i + 1}"${i === 0 ? ' autocomplete="one-time-code"' : ""}>`).join("")}</div>
        <div class="otp-foot"><span id="resend">Resend code in <span id="resend-n">30</span>s</span><button class="btn-text" type="button" id="otp-switch">${otpSwitchLabel()}</button><span class="proto">Prototype: any 6 digits work</span></div>
        <div class="otp-ok">Verification successful!</div>
      </div>`;
  function switchOtpChannel() {
    if (state.verified) return;
    state.otpChannel = state.otpChannel === "sms" ? "email" : "sms";
    $("#otp-copy").innerHTML = otpCopy();
    $("#otp-switch").textContent = otpSwitchLabel();
    startResendTimer();
    const first = $("#otp input"); if (first) first.focus();
    toast(`Code sent to ${otpDest()}`);
    agent(state.otpChannel === "sms" ? `Texted the code to ${state.maskedPhone} instead.` : `Emailed the code to ${state.maskedEmail} instead.`, { think: 250 });
  }
  function requiredLeft() {
    return unionQuestions(selectedJobs()).filter(q => q.kind === "chips" ? !state.answers[q.id] : q.kind === "textarea" ? !(state.answers[q.id] || "").trim() : !((state.answers[q.id] ?? q.prefill ?? "").trim()));
  }
  function renderStep3() {
    const sel = selectedJobs(), qs = unionQuestions(sel), asking = sel.filter(j => leftQ(j).length).length;
    const allAns = qs.length > 0 && qs.every(answered);
    state.maskedEmail = maskEmail(state.email || C.email);
    state.maskedPhone = maskPhone(state.phone || C.phone);
    state.otpMode = "send";
    state.otpChannel = state.otpChannel || "sms";
    const verifiedEarly = state.identity === "returning" && state.verified;
    setWork(`
      <h1>Confirm and send</h1>
      <div class="summary-row"><div class="avatars">${sel.slice(0, 6).map(j => `<span>${mono(j.company)}</span>`).join("")}</div><div class="txt"><b>${sel.length} ${plural(sel.length, "application")}</b>${sel.length - asking > 0 ? ` · <b>${sel.length - asking}</b> 1-click apply` : ""}${asking ? ` · <b>${asking}</b> share ${qs.filter(q => !answered(q)).length} extra ${plural(qs.filter(q => !answered(q)).length, "question")}` : ""}</div></div>
      ${qs.length ? `<section class="sec"><div class="sec-h"><div class="sec-title">${allAns ? "Reused from your last application" : "Answer once, I'll reuse it"}</div><span class="tag">${allAns ? "Edit if anything changed" : `${qs.length} ${plural(qs.length, "question")}`}</span></div>${qs.map(qHtml).join("")}</section>`
        : `<section class="sec"><div class="sec-h"><div class="sec-title">All 1-click apply</div><span class="tag">No extra questions</span></div><p class="hint" style="font-size:14px;color:var(--t2);margin:0">Your first application already answers everything these ${sel.length} employers ask.</p></section>`}
      ${verifiedEarly
        ? `<section class="otp-card ok" id="otp-card"><h2>${I.shield} Verified</h2><p>You confirmed it's you by text at the start, so there's nothing to enter here.</p><div class="otp-ok" style="margin-top:0">Verified by text</div></section>`
        : otpHtml()}
    `);
    if (!verifiedEarly) bindOtp();
    renderCta3();
    $$("[data-q]").forEach(elm => {
      if (elm.tagName === "BUTTON") elm.addEventListener("click", () => { state.answers[elm.dataset.q] = elm.dataset.v; $$(`.chip[data-q="${elm.dataset.q}"]`).forEach(c => c.classList.toggle("on", c === elm)); renderCta3(); const p = state.pending["q-" + elm.dataset.q]; if (p) p.answer(elm.dataset.v); });
      else elm.addEventListener("input", () => { state.answers[elm.dataset.q] = elm.value; renderCta3(); });
      if (elm.tagName !== "BUTTON") elm.addEventListener("blur", () => { if (textAsk.qid === elm.dataset.q && elm.value.trim()) endTextAsk(); });
    });
    $$("[data-draft]").forEach(b => b.addEventListener("click", async () => {
      const q = D.questions[b.dataset.draft]; const ta = $(`textarea[data-q="${q.id}"]`); b.disabled = true; ta.value = "";
      if (reduce) ta.value = q.draft; else for (let i = 1; i <= q.draft.length; i++) { ta.value = q.draft.slice(0, i); await wait(6); }
      state.answers[q.id] = q.draft; renderCta3();
    }));
    bindToasts();
  }
  function renderCta3() {
    const sel = selectedJobs(), left = requiredLeft(), ready = state.verified && left.length === 0;
    const meta = !state.verified && left.length ? `${left.length} ${plural(left.length, "answer")} and the code to go` : !state.verified ? "Enter the code to send" : left.length ? `${left.length} ${plural(left.length, "answer")} to go` : "Everything's ready";
    setCta(`<div class="cta-in"><div class="cta-meta"><button class="btn btn-ghost" type="button" id="back2">${I.back} Back</button><span>${meta}</span></div>
      <div class="cta-actions"><button class="btn btn-primary" type="button" id="send-all"${ready ? "" : " disabled"}>Send ${sel.length} ${plural(sel.length, "application")} ${I.send}</button></div></div>`);
    $("#back2").addEventListener("click", () => { setStep(2); renderStep2(); });
    $("#send-all").addEventListener("click", sendAll);
  }
  function startResendTimer() {
    clearInterval(state.resendTick);
    state.resendT = 30;
    const r = $("#resend"); if (r) r.innerHTML = 'Resend code in <span id="resend-n">30</span>s';
    state.resendTick = setInterval(() => {
      state.resendT--;
      const n = $("#resend-n"); if (!n) { clearInterval(state.resendTick); return; }
      if (state.resendT <= 0) { clearInterval(state.resendTick); $("#resend").innerHTML = '<button class="btn-text" type="button" data-toast="New code sent (prototype)">Resend code</button>'; bindToasts(); }
      else n.textContent = state.resendT;
    }, 1000);
  }
  /* bindOtp(onVerified): six boxes, digits only, paste-aware; on six digits it verifies, flips to the emoji run, then calls back. */
  function bindOtp(onVerified) {
    const box = $("#otp"), inputs = $$("input", box);
    startResendTimer();
    $("#otp-switch").addEventListener("click", switchOtpChannel);
    const celebrate = async () => {
      for (let i = 0; i < inputs.length; i++) { inputs[i].value = OTP_EMOJI[i]; inputs[i].classList.add("emo"); await wait(110); }
      $("#otp-card").classList.add("ok");
    };
    const check = async () => {
      if (!inputs.every(i => /^\d$/.test(i.value))) return;
      inputs.forEach(i => { i.blur(); i.readOnly = true; });
      box.classList.add("verifying");
      await wait(900);
      box.classList.remove("verifying"); box.classList.add("ok");
      await celebrate();
      state.verified = true;
      if (textAsk.key === "otp") endTextAsk();
      if (onVerified) { await wait(350); onVerified(); return; }
      renderCta3();
      agent("Verified. Ready when you are.", { think: 200, chips: reviewChips("Review and send") });
    };
    inputs.forEach((inp, i) => {
      inp.addEventListener("input", () => { if (inp.readOnly) return; inp.value = inp.value.replace(/\D/g, "").slice(-1); if (inp.value && inputs[i + 1]) inputs[i + 1].focus(); check(); });
      inp.addEventListener("keydown", e => { if (e.key === "Backspace" && !inp.value && inputs[i - 1]) inputs[i - 1].focus(); });
      inp.addEventListener("paste", e => { const d = (e.clipboardData.getData("text") || "").replace(/\D/g, ""); if (!d) return; e.preventDefault(); d.split("").slice(0, 6).forEach((ch, k) => { if (inputs[k]) inputs[k].value = ch; }); inputs[Math.min(d.length, 5)].focus(); check(); });
    });
    if (state.verified && !onVerified) { inputs.forEach((i, k) => { i.value = OTP_EMOJI[k]; i.classList.add("emo"); i.readOnly = true; }); box.classList.add("ok"); $("#otp-card").classList.add("ok"); }
  }
  /* A step-3 answer from the chat: store it, mirror it into the form so it can be reviewed and corrected there. */
  function setQ(q, v) {
    state.answers[q.id] = v;
    $$(`.chip[data-q="${q.id}"]`).forEach(c => c.classList.toggle("on", c.dataset.v === v));
    const el = $(`input[data-q="${q.id}"], textarea[data-q="${q.id}"]`); if (el) el.value = v;
    renderCta3();
  }
  async function askQuestion(q) {
    if (answered(q)) return;
    if (q.kind === "chips") { await ask("q-" + q.id, q.label, q.options.map(o => ({ value: o, label: o })), { onPick: o => setQ(q, o.value), think: 350 }); return; }
    if (q.kind === "text" && q.prefill) {
      const r = await ask("q-" + q.id, `${q.label} Your resume says ${q.prefill}. Is that right?`, [{ value: "y", label: `Yes, ${q.prefill}` }, { value: "n", label: "Change it" }], { onPick: o => { if (o.value === "y") setQ(q, q.prefill); }, think: 350 });
      if (r.value === "y") return;
    }
    if (q.draft) {
      const r = await ask("q-" + q.id, q.label, [{ value: "draft", label: "Draft it from my resume" }, { value: "own", label: "I'll write it" }], { onPick: o => { if (o.value === "draft") setQ(q, q.draft); }, think: 350 });
      if (r.value === "draft") { await agent(`Here's the draft: "${q.draft}" You can edit every word in the review.`, { think: 500 }); return; }
    }
    const done = openTextAsk(t => { const s = t.trim(); if (!s) return; setQ(q, s); agent("Got it.", { think: 200 }); endTextAsk(); }, "Type your answer…", "text", { qid: q.id });
    if (!q.draft && !(q.kind === "text" && q.prefill)) agent(q.label + (q.placeholder ? ` For example: ${q.placeholder.split("\n")[0]}` : ""), { think: 350 });
    else agent("Go ahead and type it below.", { think: 250 });
    await done;
  }
  /* Review chip: on a phone the form lives in a sheet, so the chat offers the way in. */
  const reviewChips = (label) => isMobile() ? chipRow([{ value: "r", label }], () => openReview()) : null;
  async function runStep3Chat() {
    const sel = selectedJobs(), qs = unionQuestions(sel), open = qs.filter(q => !answered(q)), asking = sel.filter(j => leftQ(j).length).length;
    if (open.length) await agent(`${open.length} short ${plural(open.length, "answer")} ${open.length === 1 ? "covers" : "cover"} ${asking} of the ${sel.length} jobs. Answer once, I'll reuse ${open.length === 1 ? "it" : "them"}.`, { think: 450 });
    else if (qs.length) await agent(`${qs.length} of the questions these jobs ask were answered on your last application, so I've reused them. Edit any that changed.`, { think: 450, chips: reviewChips("Review them") });
    else await agent(`Nothing new to answer for these ${sel.length}.`, { think: 450 });
    for (const q of open) await askQuestion(q);
    if (state.identity === "returning" && state.verified) await agent("No code this time, you verified by text at the start. Send when it looks right.", { think: 350, chips: reviewChips("Review and send") });
    else { await agent(`Last thing: I texted a 6-digit code to ${state.maskedPhone}. It confirms it's you before ${sel.length} ${plural(sel.length, "application")} go out in your name. Type it here. Prefer email? Tap the link under the code in the review.`, { think: 350 }); askCode(); }
  }

  /* ================= Sending a batch ================= */
  /* sendBatch(): the labor-illusion list. Used for the step-3 batch and for the "keep going" batch after it. */
  async function sendBatch(jobs, title) {
    setWork(`<h1>${esc(title)}</h1><p class="lede">Each one is filled on the employer's own careers site with your answers and resume.</p>
      <ul class="send-list">${jobs.map(j => `<li data-send="${j.id}"><span class="dot">${I.check}</span><span>${esc(j.company)} <span style="color:var(--t3)">· ${esc(j.city)}, ${esc(j.state)}</span></span><span class="st">Queued</span></li>`).join("")}</ul>`);
    setCta(`<div class="cta-in"><div class="cta-meta"><div class="bar"><i id="send-bar" style="width:0%"></i></div><span><b id="send-n">0</b> of ${jobs.length} sent</span></div><div class="cta-actions"><button class="btn btn-primary" disabled>Sending…</button></div></div>`);
    const per = Math.max(240, Math.min(650, 4200 / jobs.length));
    for (let i = 0; i < jobs.length; i++) {
      const li = $(`[data-send="${jobs[i].id}"]`);
      li.classList.add("doing"); li.querySelector(".st").textContent = `Filling ${19 + jobs[i].extra.length} answers`;
      if (i > 2) li.scrollIntoView({ block: "nearest", behavior: reduce ? "auto" : "smooth" });
      await wait(per);
      li.classList.remove("doing"); li.classList.add("done"); li.querySelector(".st").textContent = "Sent";
      $("#send-n").textContent = i + 1; $("#send-bar").style.width = ((i + 1) / jobs.length * 100) + "%";
    }
    await wait(500);
    state.sent = [...state.sent, ...jobs];
  }
  async function sendAll() {
    const sel = selectedJobs();
    const btn = $("#send-all"); btn.disabled = true; btn.innerHTML = "Sending…";
    /* Answers shown with a prefill and left as they were count as given (the candidate pressed send with them). */
    unionQuestions(sel).forEach(q => { if (q.kind === "text" && q.prefill && !(state.answers[q.id] || "").trim()) state.answers[q.id] = q.prefill; });
    agent(`Sending ${sel.length}. Each one goes through the employer's own site, give me a moment.`, { think: 250 });
    await sendBatch(sel, `Sending ${sel.length} ${plural(sel.length, "application")}`);
    collapseThread(`Confirm and send · ${sel.length} sent`);
    renderFinal(); runFinalChat();
  }
  function finishEarly() { state.goalDone = true; collapseThread("Add more jobs · skipped"); renderFinal(); runFinalChat(true); }

  /* ================= Final: the daily goal, then the handoff ================= */
  const answered = q => q.kind === "chips" ? !!state.answers[q.id] : !!((state.answers[q.id] ?? "").trim());
  /* Jobs for the keep-going bundle: not sent yet, every extra question already answered (so they are 1-click now), nearest first. */
  function moreJobs() {
    const sentIds = new Set(state.sent.map(j => j.id));
    return D.jobs.filter(j => !sentIds.has(j.id) && j.extra.every(k => answered(D.questions[k]))).sort(byRank);
  }
  /* Roles the candidate wanted today but the daily limit pushed to tomorrow: eligible in the step-2 pool, not sent. */
  function tomorrowQueue() { const sentIds = new Set(state.sent.map(j => j.id)); return eligible().filter(j => !sentIds.has(j.id)); }
  function notifyEmail() { return state.notifyEmail || state.email || C.email; }
  function renderFinal() {
    const n = state.sent.length, left = Math.max(0, DAILY_GOAL - n);
    const date = new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    const keepGoing = left > 0 && !state.goalDone && moreJobs().length > 0;
    if (keepGoing && !state.more) state.more = new Set(moreJobs().slice(0, left).map(j => j.id));
    const more = keepGoing ? moreJobs().slice(0, left) : [];
    const onCount = more.filter(j => state.more.has(j.id)).length;
    setStep(4);
    setWork(`
      <div class="black-card"><div class="bc-num">${n}</div><div><div class="bc-title">${plural(n, "application")} sent today</div><div class="bc-sub">${n > 1 ? `West Alamo Dental Care and ${n - 1} more` : "West Alamo Dental Care"} · ${date}</div></div></div>
      ${keepGoing ? `
      <section class="goal">
        <div class="goal-h"><h2>Keep going: <b>${n} of ${DAILY_GOAL}</b> today</h2><span class="goal-n">${left} to go</span></div>
        <div class="goal-bar"><i style="width:${n / DAILY_GOAL * 100}%"></i></div>
        <p>${left === 1 ? "One more" : `${left} more`} and you've hit ${DAILY_GOAL}. ${more.length === 1 ? "This one is" : "All"} 1-click apply, I already have every answer.</p>
        <ul class="more">${more.map(j => jobRow(j, state.more.has(j.id), false)).join("")}</ul>
        <div class="final-actions"><button class="btn btn-primary" type="button" id="send-more"${onCount ? "" : " disabled"}>Send ${onCount} more ${I.send}</button><button class="btn-text" type="button" id="goal-done">I'm done for today</button></div>
      </section>` : ""}
      <section class="next" id="next">
        <h2>${n >= DAILY_GOAL ? `Great job, that's ${n} in a day.` : keepGoing ? "What happens next" : `Done for today, ${n} sent.`}</h2>
        <p><b>Employers reply directly</b>, by email or phone, usually within a week. I'll email you the moment one does, and send tomorrow's matches${n >= DAILY_GOAL && tomorrowQueue().length ? ` (starting with the <b>${tomorrowQueue().length}</b> that didn't fit today)` : ""} to:</p>
        <div class="email-row"><span class="val" id="notify-val">${esc(notifyEmail())}</span><button class="btn-text" type="button" id="email-edit">Edit</button></div>
        <div class="email-edit"><input type="email" id="notify-in" value="${esc(notifyEmail())}" aria-label="Email for replies and new matches"><button class="btn btn-primary" type="button" id="email-save">Save</button><button class="btn-text" type="button" id="email-cancel">Cancel</button></div>
        ${keepGoing ? "" : `<div class="final-actions"><button class="btn btn-secondary" type="button" data-close>Back to LinkedIn</button></div>`}
      </section>
      <p class="kicker" style="margin-top:26px">Sent today</p>
      <ul class="sent-grid">${state.sent.map(j => `<li><span class="mono">${mono(j.company)}</span><span><b>${esc(j.company)}</b><small>${esc(j.city)}, ${esc(j.state)}</small></span><span class="st">${I.check}</span></li>`).join("")}</ul>
    `);
    setCta(""); bindToasts();
    $$(".goal .job").forEach(row => row.addEventListener("click", () => { const id = row.dataset.job; if (state.more.has(id)) state.more.delete(id); else state.more.add(id); const st = workScroll.scrollTop; renderFinal(); workScroll.scrollTop = st; }));
    const sm = $("#send-more"); if (sm) sm.addEventListener("click", () => sendMore("form"));
    const gd = $("#goal-done"); if (gd) gd.addEventListener("click", () => dismissGoal("form"));
    const nx = $("#next");
    $("#email-edit").addEventListener("click", () => { nx.classList.add("editing"); const i = $("#notify-in"); i.focus(); i.select(); });
    $("#email-cancel").addEventListener("click", () => { nx.classList.remove("editing"); $("#notify-in").value = notifyEmail(); });
    const save = () => {
      const v = $("#notify-in").value.trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) { $("#notify-in").focus(); toast("That doesn't look like an email address"); return; }
      const changed = v !== notifyEmail();
      state.notifyEmail = v; $("#notify-val").textContent = v; nx.classList.remove("editing");
      if (changed) agent(`Got it. Replies and tomorrow's matches go to ${v}.`, { think: 250 });
    };
    $("#email-save").addEventListener("click", save);
    $("#notify-in").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); save(); } if (e.key === "Escape") $("#email-cancel").click(); });
  }
  async function sendMore(source) {
    const jobs = moreJobs().filter(j => state.more.has(j.id));
    if (!jobs.length) return;
    if (source === "form" && state.pending.more) state.pending.more.answer("send");
    const btn = $("#send-more"); if (btn) { btn.disabled = true; btn.innerHTML = "Sending…"; }
    agent(`Sending ${jobs.length} more.`, { think: 200 });
    await sendBatch(jobs, `Sending ${jobs.length} more`);
    state.more = null;
    renderFinal(); runFinalChat();
  }
  function dismissGoal(source) {
    state.goalDone = true;
    if (source === "form" && state.pending.more) state.pending.more.answer("done");
    renderFinal();
    if (source === "form") agent(`No problem. Tomorrow's matches go to ${notifyEmail()}, change it on the right if you'd rather use another address.`, { think: 300 });
  }
  async function runFinalChat(early) {
    const n = state.sent.length, left = DAILY_GOAL - n, more = moreJobs().slice(0, Math.max(0, left));
    if (early) { await agent(`No problem. I'll email you when West Alamo replies, and send tomorrow's matches to ${notifyEmail()}. Change it on the right if you'd rather use another address.`, { think: 450 }); return; }
    if (n >= DAILY_GOAL || state.goalDone || !more.length) {
      const tq = tomorrowQueue().length;
      await agent(`All ${n} sent. ${n >= DAILY_GOAL ? `Great job, that's ${n} in a day. ` : ""}Tomorrow's matches${n >= DAILY_GOAL && tq ? `, starting with the ${tq} that didn't fit today,` : ""} go to ${notifyEmail()}, change it on the right if you'd rather use another address.`, { think: 450 });
      return;
    }
    await agent(`All ${n} sent.`, { think: 400 });
    await ask("more", `You're ${left} away from ${DAILY_GOAL} today. ${more.length === 1 ? "This one is" : `These ${more.length} are`} 1-click apply, send ${more.length === 1 ? "it" : "them"}?`, [{ value: "send", label: `Send ${more.length} more` }, { value: "done", label: "I'm done for today" }], {
      onPick: (o, first) => { if (!first) return; if (o.value === "send") sendMore("chat"); else { dismissGoal("chat"); agent(`No problem. Tomorrow's matches go to ${notifyEmail()}, change it on the right if you'd rather use another address.`, { think: 300 }); } }, think: 350,
    });
  }

  /* ================= Composer, notes, entry ================= */
  $("#composer").addEventListener("submit", e => {
    e.preventDefault();
    const inp = $("#composer input"), t = inp.value.trim(); if (!t) return;
    inp.value = ""; user(t);
    if (textAsk.handle) { textAsk.handle(t); return; }
    agent(state.step === 1
      ? "I can only answer from the job post itself. West Alamo lists full-time, on-site, in San Antonio, with pay marked as competitive. Anything beyond that I'd be guessing, so I won't."
      : "Good question. I can only answer from the job posts I'm applying to, so I'll stick to what they say. Anything you'd like me to change in the list?", { think: 700 });
  });

  const NOTES = {
    1: ["Email first, because it's the key", "One field decides the path. Known: the saved resume and answers load. New: resume upload, and the form fills from it. The why-text says exactly what the email is for.",
      "Verify when you unlock, not before you send", "A known email never loads anyone's details on its own. The code goes to the phone on the saved profile; 6 digits buys 19 answers, and that code also covers the batch send later. New candidates verify at the end instead.",
      "The preview is the trust moment", "File name, upload date, which application it came from, and the extracted summary, before anything is attached. Preview opens the rendered document. Past 90 days the card leads with the age and Replace becomes the primary button.",
      "Resume first for new candidates", "The only thing a stranger will give you in the first ten seconds is a file they already have. Everything else is derived from it.",
      "The wait is the product", "Reading takes 5 to 7 seconds, so the card narrates it in four stages with a progress bar. Shown work raises perceived value (labor illusion, Buell and Norton).",
      "Fields fill in front of you", "Eleven answers appear one by one, then the counter sits at 15 of 19. Progress is endowed, not promised.",
      "Every field says why", "Phone: for interview calls, nothing else. Backup email: their system rejects duplicates. The objection is answered before it forms.",
      "The chat is a narrator, not a chatbot", "It does visible work before it asks for anything, so the three questions that follow feel earned. No company name until the candidate has a reason to care.",
      "No OTP here", "The first application has zero friction. Verification moves to the moment it feels fair."],
    2: ["Start with a bundle, not a blank", "The 1-click roles around San Antonio are already ticked when the page opens. The question is what to remove, not where to begin.",
      "Ten a day, said up front", "The limit sits above the list, in the button's count, and on the rows it affects (a quiet Tomorrow tag). Nothing is lost: what doesn't fit today leads tomorrow's email, so the limit becomes the reason to open it.",
      "Say why, in one line", "A single match line at the top, a fit line on every row (distance from the job they chose, practice type, pay).",
      "Same controls in two places", "The chips in the chat and the strip above the list are the same state. Either one answers the question.",
      "Liquidity-aware choices", "Every option shows the count behind it, so candidates choose from what exists. Same mechanic as CareerGPT's related-search counts.",
      "Effort as a quiet sub-metric", "Extra questions per job sit in grey under the row. Ready rows don't repeat what the tier already says.",
      "One colour for the next action", "Cobalt is reserved for the button that moves you on, the current step and progress. Selection stays black so the accent keeps its meaning.",
      "The rail folds behind you", "Each finished step collapses to one row in the chat, so the thread is only ever about the step you're on.",
      "The answer bank compounds", "Questions answered on any earlier application don't count any more, so for a returning candidate most quick roles are already 1-click. Every career site they apply on makes the next one shorter."],
    3: ["Answer once, apply many", "The extra questions are the union across the quick tier, so three answers cover every job that asks.",
      "OTP last, where it feels fair", "Before 16 applications go out in your name is a reason people accept. OTP first was a tax on strangers.",
      "Celebrate the unlock", "The code boxes turn into the emoji run from today's product. A small peak right before the big send."],
    4: ["A goal with a bar, not a nag", "Ten in a day. The card shows where you are, and offers only 1-click roles, because every answer is already in hand. One tap, no new OTP.",
      "Make the exit equal", "I'm done for today sits next to the send button at the same size, and the ending is just as warm.",
      "Say where the replies go", "The email address is shown and editable here, where it matters, instead of buried in settings.",
      "Strong ending", "One black card with the number, then tomorrow's matches as the reason to come back."],
    5: ["The chat is the page", "There's no room for two panes on a phone, so every question is asked in one place: the chat. Your email, anything the resume couldn't supply, the employer's extra questions and the 6-digit code are all typed or tapped there.",
      "The form is for review", "Everything you've answered lands in the form, which opens as a sheet from the bar above the message box. That's where you check and correct, with a quiet reason on any field that needs fixing. On desktop the same rule holds: the form shows a field as \"In the chat\" until it's answered.",
      "Bad input is explained where it was typed", "A wrong phone number or email gets the exact problem in the chat, an echo of what you typed with the problem marked, and the retry goes straight into the same message box.",
      "Code by text first", "The phone is already in hand and SMS codes autofill on it. Type or paste the code in the chat. Email is one tap away in the review, never a second screen."],
  };
  $("#notes-body").innerHTML = [1, 2, 3, 4, 5].map(s => `<div class="note-step" data-step="${s}"><p class="kicker">${s < 4 ? `Step ${s} · ${["Apply", "Add more jobs", "Confirm and send"][s - 1]}` : s === 4 ? "After sending" : "On a phone"}</p>${NOTES[s].reduce((acc, v, i, arr) => i % 2 === 0 ? acc + `<div class="note"><span class="num">${i / 2 + 1}</span><div><b>${esc(v)}.</b> ${esc(arr[i + 1])}</div></div>` : acc, "")}</div>`).join("");
  $("#notes-btn").addEventListener("click", e => { e.preventDefault(); $("#notes").classList.toggle("open"); });
  $("#notes-close").addEventListener("click", () => $("#notes").classList.remove("open"));
  $("#restart").addEventListener("click", () => location.reload());
  document.addEventListener("keydown", e => { if (e.key === "Escape") $("#notes").classList.remove("open"); });

  function openPanel() { const p = $("#panel"); if (!p.hidden) return; p.hidden = false; if (!state.opened) { state.opened = true; setStep(1); renderStep1(); runStep1Chat(); } }
  function closePanel() { $("#panel").hidden = true; }
  $("#start").addEventListener("click", openPanel);
  $$("[data-start]").forEach(b => b.addEventListener("click", openPanel));
  document.addEventListener("click", e => { const t = e.target.closest("[data-close]"); if (t) { e.preventDefault(); closePanel(); } });
  bindToasts();
  setStep(1);
})();
