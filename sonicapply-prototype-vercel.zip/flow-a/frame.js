/* Prototype-only: Desktop / Mobile toggle. Mobile loads this same prototype in a 390 x 844 phone frame so the real
   mobile breakpoint applies. ?embed=1 marks the copy inside the frame (no toggle there). */
(() => {
  if (/[?&]embed\b/.test(location.search)) { document.documentElement.classList.add("is-embed"); return; }
  const SRC = (window.SA_FRAME_SRC || "index.html") + "?embed=1";
  const bar = document.createElement("div");
  bar.className = "devtoggle"; bar.setAttribute("role", "group"); bar.setAttribute("aria-label", "Preview size");
  bar.innerHTML = '<button type="button" data-m="desktop" class="on">Desktop</button><button type="button" data-m="mobile">Mobile</button>';
  const wrap = document.createElement("div");
  wrap.className = "simwrap"; wrap.hidden = true;
  wrap.innerHTML = '<div class="phone-box"><div class="phone"><iframe title="SonicApply on a phone" allow=""></iframe></div></div><p class="sim-note">Mobile view, 390 px wide. <button type="button" class="btn-text" id="sim-restart">Restart</button></p>';
  document.body.append(bar, wrap);
  const frame = wrap.querySelector("iframe");
  /* Size the phone to the space actually available: it gets shorter before it gets smaller, so text stays full size.
     Only a window too small for even a short phone scales it down. */
  const fit = () => {
    const availH = Math.max(300, wrap.clientHeight - 96), availW = Math.max(240, wrap.clientWidth - 32);
    const h = Math.min(844, Math.max(560, availH));
    const s = Math.max(.35, Math.min(1, availH / h, availW / 390));
    wrap.style.setProperty("--h", h + "px"); wrap.style.setProperty("--s", s);
  };
  const set = m => {
    bar.querySelectorAll("button").forEach(b => b.classList.toggle("on", b.dataset.m === m));
    document.body.classList.toggle("sim-mobile", m === "mobile");
    wrap.hidden = m !== "mobile";
    if (m === "mobile") { fit(); if (!frame.getAttribute("src")) frame.src = SRC; }
  };
  bar.addEventListener("click", e => { const b = e.target.closest("button"); if (b) set(b.dataset.m); });
  wrap.querySelector("#sim-restart").addEventListener("click", () => { frame.src = SRC; });
  window.addEventListener("resize", () => { if (!wrap.hidden) fit(); });
  if (window.ResizeObserver) new ResizeObserver(() => { if (!wrap.hidden) fit(); }).observe(wrap);
})();
